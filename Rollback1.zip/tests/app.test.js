const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Core = require('../app/app.js');

assert.strictEqual(Core.parseMoney('1.234,56'), 1234.56);
assert.strictEqual(Core.parseMoney('R$ 89,90'), 89.90);
assert.strictEqual(Core.monthFromBR('15/07/2026'), '2026-07');
assert.strictEqual(Core.addMonthsKey('2026-12', 1), '2027-01');

const state = Core.defaultState();
state.entries.push({id:'1', title:'Venda', amount:1000, type:'Receita', category:'Vendas', date:'10/07/2026', status:'Pago', notes:''});
state.entries.push({id:'2', title:'Mercado', amount:250, type:'Despesa', category:'Mercado', date:'12/07/2026', status:'Previsto', notes:''});
state.cards.push({id:'card1', name:'Nubank', firstDigits:'', lastDigits:'1234', limit:2000, closingDay:20, dueDay:10, colorName:'Roxo', brandName:'Mastercard'});
state.cardTransactions.push({id:'ct1', cardId:'card1', title:'Notebook', amount:1200, category:'Compras', date:'01/07/2026', billingMonthOffset:0, installments:3, recurrenceMonths:0, consumeTotalLimit:false, notes:''});
state.salaryRecords.push({month:'2026-07', grossSalary:3000, notes:'', items:[{id:'s1', name:'INSS', type:'Desconto', valueMode:'Percentual', value:10, fixedMonthly:true, notes:''}]});

const dash = Core.dashboard(state, '2026-07');
assert.strictEqual(dash.expectedIncome, 1000);
assert.strictEqual(dash.expectedExpense, 250);
assert.strictEqual(dash.openInvoice, 0);
assert.strictEqual(dash.salaryNet, 2700);
assert.strictEqual(dash.expectedBalance, 3450);

state.loans.push({id:'loan-month',name:'Parcela mensal',direction:'Peguei emprestado',principalAmount:600,installmentAmount:200,installments:3,firstDueDate:'10/07/2026',payments:[]});
state.subscriptions.push({id:'sub-month',name:'Internet',kind:'Serviço',amount:90,billingCycle:'Mensal',dueDay:15,startDate:'15/07/2026',active:true});
const integratedDash = Core.dashboard(state, '2026-07');
assert.strictEqual(integratedDash.expectedExpense, 540);
assert.strictEqual(integratedDash.expectedBalance, 3160);
assert.strictEqual(integratedDash.openInvoice, 0);
const movements = Core.monthlyMovements(state, '2026-07');
assert.ok(movements.some((item) => item.module === 'Salário'));
assert.ok(movements.some((item) => item.module === 'Empréstimos'));
assert.ok(movements.some((item) => item.module.indexOf('Assinaturas') === 0));

state.salaryRecords[0].items.push({id:'clt1', name:'Empréstimo 3722', type:'Empréstimo CLT', valueMode:'Valor', value:200, fixedMonthly:true, startMonth:'2026-07', endMonth:'2026-08', notes:''});
assert.strictEqual(Core.dashboard(state, '2026-07').salaryNet, 2500);
assert.strictEqual(Core.dashboard(state, '2026-08').salaryNet, 2500);
assert.strictEqual(Core.dashboard(state, '2026-09').salaryNet, 2700);

assert.strictEqual(Core.cardTransactionIsBilledIn(state.cardTransactions[0], '2026-07'), true);
assert.strictEqual(Core.cardTransactionIsBilledIn(state.cardTransactions[0], '2026-10'), false);
assert.strictEqual(Core.cardBilledAmount(state.cardTransactions[0]), 400);
state.invoicePayments.push({id:'pay1', cardId:'card1', month:'2026-07', paidAmount:100, paidDate:'15/07/2026'});
const cardSummary = Core.cardSummary(state, '2026-07');
assert.deepStrictEqual(cardSummary, {
  cardCount: 1,
  purchaseCount: 1,
  purchaseTotal: 400,
  totalLimit: 2000,
  committedLimit: 400,
  availableLimit: 1600,
  invoiceTotal: 400,
  paidTotal: 100,
  openTotal: 300
});

const schedule = Core.loanSchedule({firstDueDate:'10/07/2026', installments:3, installmentAmount:100, payments:[{number:2, paidDate:'11/08/2026'}]});
assert.strictEqual(schedule.length, 3);
assert.strictEqual(schedule[1].paid, true);
assert.strictEqual(schedule[2].dueDate, '10/09/2026');

const due = Core.nextSubscriptionDue({name:'App', amount:120, billingCycle:'Anual', dueDay:15, startDate:'15/07/2026'}, new Date(2026, 6, 16));
assert.strictEqual(due, '15/07/2027');
assert.strictEqual(Core.subscriptionMonthlyEquivalent({amount:120, billingCycle:'Anual'}), 10);

const recurring = Core.buildRecurringEntries({
  id:'r1',
  title:'Financiamento',
  amount:500,
  type:'Despesa',
  category:'Casa',
  date:'31/01/2026',
  status:'Previsto',
  notes:''
}, 3);
assert.strictEqual(recurring.length, 3);
assert.strictEqual(recurring[0].date, '31/01/2026');
assert.strictEqual(recurring[1].date, '28/02/2026');
assert.strictEqual(recurring[2].date, '31/03/2026');
assert.strictEqual(recurring[2].recurringIndex, 3);
assert.strictEqual(recurring[2].recurringTotal, 3);
assert.strictEqual(recurring[2].recurringFrequency, 'Mensal');

[
  'app/index.html',
  'app/styles.css',
  'app/app.js',
  'app/app.webmanifest',
  'app/assets/rb_gestao.ico',
  'app/assets/rb_gestao_app_icon.png',
  'Abrir RB Gestão Financeira.bat',
  'Criar atalho na área de trabalho.bat'
].forEach((file) => {
  assert.ok(fs.existsSync(path.join(__dirname, '..', file)), `Arquivo obrigatório ausente: ${file}`);
});

const html = fs.readFileSync(path.join(__dirname, '..', 'app/index.html'), 'utf8');
assert.ok(html.includes('app.webmanifest'));
assert.ok(html.includes('RB Gestão Financeira'));

console.log('Todos os testes passaram.');
