RB GESTÃO FINANCEIRA — VERSÃO 1.3 PARA WINDOWS

INSTALAÇÃO

1. Execute release\RB_Gestao_Financeira_Setup_1.3.0.exe.
2. Escolha a pasta de instalação.
3. O instalador cria o atalho RB Gestão Financeira na Área de Trabalho e no
   Menu Iniciar.
4. Ao atualizar a versão anterior, o atalho separado RB Gestão Cartões é
   removido automaticamente. Os dados dos cartões permanecem preservados.

O aplicativo possui uma janela nativa Electron e não depende do Microsoft Edge,
Chrome, Node.js ou servidor externo. O ícone RB Gestão identifica o executável,
os atalhos e a janela na barra de tarefas.

DADOS

- Os dados ficam armazenados localmente neste computador.
- Os registros encontrados na versão anterior foram migrados para a primeira
  execução desta versão.
- Use Backup > Exportar backup para guardar uma cópia JSON.
- Use Backup > Importar backup para restaurar ou trocar de computador.
- A desinstalação não apaga automaticamente os dados do usuário.

COMPETÊNCIA E NAVEGAÇÃO

- Uma nova abertura começa sempre no mês seguinte ao mês atual.
- Alterar a tela, o mês, os filtros ou a ordenação e pressionar F5 mantém o
  usuário no mesmo contexto.

CÁLCULO DO PAINEL

O painel consolida por competência:
- salário líquido, já com proventos, descontos e empréstimos CLT vigentes;
- receitas e despesas;
- parcelas de empréstimos a pagar e a receber;
- assinaturas mensais, trimestrais ou anuais devidas naquele mês.

Cartões e faturas ficam no mesmo aplicativo, mas não entram nos cálculos do
painel financeiro.

O painel inicial apresenta três totais informativos dos cartões: limite total,
limite disponível e faturas da competência. Esses valores permanecem fora do
cálculo do saldo previsto.

FILTROS E ORDENAÇÃO

As telas com registros do aplicativo possuem filtros e ordenação próprios
por tipo, situação, direção, ciclo, data, nome e valor, conforme as informações
disponíveis. O módulo de Cartões também filtra por cartão e situação da
fatura e ordena cartões e compras separadamente.

O topo do módulo Cartões apresenta um resumo consolidado da competência com
quantidade de cartões e compras, limites total, comprometido e disponível,
faturas, pagamentos e valores em aberto. Os totais acompanham os filtros.

EMPRÉSTIMOS CLT NO SALÁRIO

No módulo Salário, o tipo Empréstimo CLT possui competência inicial e final do
contrato. O valor é descontado somente nos meses dentro da vigência, aparece
separado dos demais descontos e participa do cálculo do salário líquido.

MÓDULOS

- Início
- Transações
- Cartões
- Salário
- Empréstimos
- Assinaturas
- Categorias
- Backup
- Help

A aba Help contém o tutorial completo do sistema, com instruções de uso para
todos os módulos, cálculos, filtros, navegação mensal e proteção dos dados.
