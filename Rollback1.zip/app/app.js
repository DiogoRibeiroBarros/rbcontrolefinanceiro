(function (root) {
  'use strict';

  var STORE_KEY = 'rb_gestao_financeira_windows_v120';
  var UI_STORE_KEY = 'rb_gestao_financeira_windows_ui_v120';
  var MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  var screens = [
    { id: 'dashboard', title: 'Início', subtitle: 'Resumo financeiro do mês selecionado', icon: '🏠' },
    { id: 'entries', title: 'Transações', subtitle: 'Receitas, despesas e status de pagamento', icon: '🧾' },
    { id: 'cards', title: 'Cartões', subtitle: 'Cartões, compras e faturas sem impacto no saldo financeiro', icon: '💳' },
    { id: 'salary', title: 'Salário', subtitle: 'Salário bruto, proventos, descontos e líquido', icon: '💵' },
    { id: 'loans', title: 'Empréstimos', subtitle: 'Controle de parcelas a pagar e a receber', icon: '🏦' },
    { id: 'subscriptions', title: 'Assinaturas', subtitle: 'Aplicativos, jogos, streaming e recorrências', icon: '🔁' },
    { id: 'categories', title: 'Categorias', subtitle: 'Cadastros usados nos lançamentos', icon: '🏷️' },
    { id: 'backup', title: 'Backup', subtitle: 'Exportar, importar e zerar os dados locais', icon: '💾' },
    { id: 'help', title: 'Help', subtitle: 'Tutorial completo para utilizar o sistema', icon: '❓' }
  ];

  var defaultCategories = {
    income: ['Salário','Comissões','Vendas','Empréstimos recebidos','Outras receitas'],
    expense: ['Assinaturas','Compras avulsas','Casa','Mercado','Plano celular','Plano de saúde','Mecânico','Empréstimos','Outras despesas'],
    card: ['Assinaturas','Mercado','Alimentação','Transporte','Compras','Serviços','Saúde','Outros cartão'],
    salary: ['Salário fixo','Comissões','Bônus','Adiantamento','Descontos','Outros salário'],
    loan: ['Empréstimos recebidos','Empréstimos para terceiros','Parcelas recebidas','Parcelas pagas','Juros','Outros empréstimos']
  };

  var state = null;
  var activeScreen = 'dashboard';
  var selectedMonth = addMonthsKey(monthKey(new Date()), 1);
  var searchText = '';
  var viewOptions = {
    cards: { status:'Todos', sort:'name-asc', purchaseCard:'Todos', purchaseSort:'date-desc' },
    dashboard: { type:'Todos', sort:'date-asc' },
    entries: { type:'Todos', status:'Todos', sort:'date-asc' },
    salary: { type:'Todos', sort:'name-asc' },
    loans: { direction:'Todos', status:'Todos', sort:'name-asc' },
    subscriptions: { status:'Todos', cycle:'Todos', sort:'name-asc' },
    categories: { sort:'name-asc' }
  };

  function clone(obj) { return JSON.parse(JSON.stringify(obj)); }
  function uid() { return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9); }
  function pad(n) { return String(n).padStart(2, '0'); }
  function todayBR() { return formatDateBR(new Date()); }
  function monthKey(date) { return date.getFullYear() + '-' + pad(date.getMonth() + 1); }
  function monthTitle(key) {
    var parts = String(key).split('-');
    var year = Number(parts[0]);
    var month = Number(parts[1]) - 1;
    return MONTHS[month] + ' de ' + year;
  }
  function addMonthsKey(key, delta) {
    var parts = key.split('-');
    var d = new Date(Number(parts[0]), Number(parts[1]) - 1 + delta, 1);
    return monthKey(d);
  }
  function parseDateBR(value) {
    if (!value) return new Date();
    var text = String(value).trim();
    var iso = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) return new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
    var br = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (br) return new Date(Number(br[3]), Number(br[2]) - 1, Number(br[1]));
    var parsed = new Date(text);
    return isNaN(parsed.getTime()) ? new Date() : parsed;
  }
  function formatDateBR(date) { return pad(date.getDate()) + '/' + pad(date.getMonth() + 1) + '/' + date.getFullYear(); }
  function dateInputFromBR(value) {
    var d = parseDateBR(value);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function dateBRFromInput(value) { return value ? formatDateBR(parseDateBR(value)) : todayBR(); }
  function monthFromBR(value) { return monthKey(parseDateBR(value)); }
  function recurrenceSummary(entry) {
    if (!entry || !entry.recurringGroupId || Number(entry.recurringTotal || 0) <= 1) return '';
    return ' · recorrente ' + Number(entry.recurringIndex || 1) + '/' + Number(entry.recurringTotal || 1);
  }
  function buildRecurringEntries(entry, months) {
    var total = Math.max(1, Math.min(360, Number(months || 1)));
    if (total === 1) return [entry];
    var baseDate = parseDateBR(entry.date);
    var groupId = entry.recurringGroupId || uid();
    var list = [];
    for (var i = 0; i < total; i++) {
      var next = clone(entry);
      next.id = i === 0 && entry.id ? entry.id : uid();
      next.date = formatDateBR(addMonthsDate(baseDate, i));
      next.recurringGroupId = groupId;
      next.recurringIndex = i + 1;
      next.recurringTotal = total;
      next.recurringFrequency = 'Mensal';
      list.push(next);
    }
    return list;
  }
  function parseMoney(value) {
    if (typeof value === 'number') return isFinite(value) ? value : 0;
    var text = String(value || '').trim().replace(/R\$/gi, '').replace(/\s/g, '');
    if (!text) return 0;
    if (text.indexOf(',') >= 0) text = text.replace(/\./g, '').replace(',', '.');
    var n = Number(text);
    return isFinite(n) ? Math.round(n * 100) / 100 : 0;
  }
  function money(value) {
    return Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
  }
  function normalizeText(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  }
  function defaultState() {
    return {
      version: '1.3.0-windows',
      createdAt: new Date().toISOString(),
      entries: [],
      categories: clone(defaultCategories),
      cards: [],
      cardTransactions: [],
      invoicePayments: [],
      loans: [],
      subscriptions: [],
      salaryRecords: []
    };
  }
  function normalizeState(input) {
    var base = defaultState();
    var next = input && typeof input === 'object' ? input : {};
    Object.keys(base).forEach(function (k) {
      if (k !== 'categories' && next[k] !== undefined) base[k] = next[k];
    });
    base.categories = clone(defaultCategories);
    if (next.categories) {
      Object.keys(defaultCategories).forEach(function (k) {
        if (Array.isArray(next.categories[k]) && next.categories[k].length) {
          base.categories[k] = next.categories[k].map(String);
        }
      });
    }
    ['entries','cards','cardTransactions','invoicePayments','loans','subscriptions','salaryRecords'].forEach(function (k) {
      if (!Array.isArray(base[k])) base[k] = [];
    });
    base.version = '1.3.0-windows';
    return base;
  }
  function loadState() {
    try {
      var raw = root.localStorage ? root.localStorage.getItem(STORE_KEY) : null;
      if (!raw && root.document && typeof root.XMLHttpRequest === 'function') {
        try {
          var legacyRequest = new root.XMLHttpRequest();
          legacyRequest.open('GET', 'legacy-data.json', false);
          legacyRequest.send(null);
          if (legacyRequest.status === 0 || (legacyRequest.status >= 200 && legacyRequest.status < 300)) raw = legacyRequest.responseText;
        } catch (legacyError) {}
      }
      state = normalizeState(raw ? JSON.parse(raw) : null);
      if (raw && root.localStorage && !root.localStorage.getItem(STORE_KEY)) saveState();
    } catch (err) {
      state = defaultState();
      toast('Não foi possível ler os dados locais. Iniciado com base zerada.');
    }
  }
  function saveState() {
    if (!state) return;
    state.updatedAt = new Date().toISOString();
    root.localStorage.setItem(STORE_KEY, JSON.stringify(state));
  }

  function loadUiState() {
    try {
      var raw = root.sessionStorage ? root.sessionStorage.getItem(UI_STORE_KEY) : null;
      var saved = raw ? JSON.parse(raw) : null;
      if (saved && screens.some(function(screen){ return screen.id === saved.activeScreen; })) activeScreen = saved.activeScreen;
      if (saved && /^\d{4}-\d{2}$/.test(saved.selectedMonth || '')) selectedMonth = saved.selectedMonth;
      if (saved && saved.viewOptions && typeof saved.viewOptions === 'object') {
        Object.keys(viewOptions).forEach(function(key){
          if (saved.viewOptions[key]) viewOptions[key] = Object.assign({}, viewOptions[key], saved.viewOptions[key]);
        });
      }
    } catch (err) {
      activeScreen = 'dashboard';
      selectedMonth = addMonthsKey(monthKey(new Date()), 1);
    }
  }
  function saveUiState() {
    if (!root.sessionStorage) return;
    root.sessionStorage.setItem(UI_STORE_KEY, JSON.stringify({ activeScreen: activeScreen, selectedMonth: selectedMonth, viewOptions: viewOptions }));
  }

  function compareText(a, b) { return String(a || '').localeCompare(String(b || ''), 'pt-BR', { sensitivity:'base' }); }
  function sortRecords(list, sort, selectors) {
    var copy = list.slice();
    var parts = String(sort || '').split('-');
    var direction = parts.pop() === 'desc' ? -1 : 1;
    var fieldName = parts.join('-');
    var selector = selectors[fieldName] || selectors.name;
    return copy.sort(function(a,b){
      var av = selector(a), bv = selector(b);
      if (typeof av === 'number' || typeof bv === 'number') return (Number(av || 0) - Number(bv || 0)) * direction;
      if (av instanceof Date || bv instanceof Date) return ((av ? av.getTime() : 0) - (bv ? bv.getTime() : 0)) * direction;
      return compareText(av, bv) * direction;
    });
  }
  function filterSelect(id, label, options, selected) {
    return '<label class="filter-field"><span>' + escapeHtml(label) + '</span><select id="' + id + '" class="select compact-select">' + options.map(function(option){ return '<option value="' + escapeHtml(option.value) + '" ' + (option.value === selected ? 'selected' : '') + '>' + escapeHtml(option.label) + '</option>'; }).join('') + '</select></label>';
  }
  function filterBar(content) { return '<div class="filter-bar">' + content + '</div>'; }

  function entryMatchesMonth(e, key) { return monthFromBR(e.date) === key; }
  function entriesForMonth(key) { return state.entries.filter(function(e){ return entryMatchesMonth(e, key); }); }
  function sum(list, fn) { return list.reduce(function(acc, item){ return acc + fn(item); }, 0); }
  function roundMoney(value) { return Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100; }

  function salaryRecordForMonth(key) {
    var exact = state.salaryRecords.find(function(r){ return r.month === key; });
    var prev = exact || state.salaryRecords
      .filter(function(r){ return r.month <= key; })
      .sort(function(a,b){ return a.month < b.month ? 1 : -1; })[0];
    var record = prev ? {
      month: key,
      grossSalary: Number(prev.grossSalary || 0),
      notes: prev.notes || '',
      items: (prev.items || []).filter(function(i){ return exact || i.fixedMonthly; }).filter(function(i){ return !salaryItemIsLoan(i); })
    } : { month: key, grossSalary: 0, notes: '', items: [] };
    var loanItems = {};
    state.salaryRecords.slice().sort(function(a,b){ return a.month < b.month ? -1 : 1; }).forEach(function(salaryRecord){
      (salaryRecord.items || []).forEach(function(item){ if (salaryItemIsLoan(item)) loanItems[item.id] = item; });
    });
    Object.keys(loanItems).forEach(function(id){
      if (salaryItemAppliesInMonth(loanItems[id], key)) record.items.push(loanItems[id]);
    });
    return record;
  }
  function upsertSalaryRecord(record) {
    var idx = state.salaryRecords.findIndex(function(r){ return r.month === record.month; });
    if (idx >= 0) state.salaryRecords[idx] = record; else state.salaryRecords.push(record);
  }
  function salaryItemAmount(item, gross) {
    if (item.valueMode === 'Percentual') return roundMoney(Number(gross || 0) * Number(item.value || 0) / 100);
    return roundMoney(item.value || 0);
  }
  function salaryItemIsLoan(item) { return item && (item.type === 'Empréstimo CLT' || item.type === 'Empréstimo'); }
  function salaryItemAppliesInMonth(item, key) {
    if (!salaryItemIsLoan(item)) return true;
    var start = item.startMonth || '';
    var end = item.endMonth || '';
    return (!start || key >= start) && (!end || key <= end);
  }
  function salaryTotals(key) {
    var r = salaryRecordForMonth(key);
    var earnings = sum(r.items || [], function(i){ return i.type === 'Recebimento' ? salaryItemAmount(i, r.grossSalary) : 0; });
    var deductions = sum(r.items || [], function(i){ return i.type === 'Desconto' ? salaryItemAmount(i, r.grossSalary) : 0; });
    var loanDeductions = sum(r.items || [], function(i){ return salaryItemIsLoan(i) && salaryItemAppliesInMonth(i,key) ? salaryItemAmount(i, r.grossSalary) : 0; });
    return { record: r, earnings: roundMoney(earnings), deductions: roundMoney(deductions), loanDeductions: roundMoney(loanDeductions), net: roundMoney(Number(r.grossSalary || 0) + earnings - deductions - loanDeductions) };
  }

  function addMonthsDate(date, months) {
    var d = new Date(date.getFullYear(), date.getMonth() + months, date.getDate());
    if (d.getDate() !== date.getDate()) d = new Date(date.getFullYear(), date.getMonth() + months + 1, 0);
    return d;
  }
  function cardTransactionIsBilledIn(t, key) {
    var start = parseDateBR(t.date);
    start = new Date(start.getFullYear(), start.getMonth() + Number(t.billingMonthOffset || 0), 1);
    var targetParts = key.split('-');
    var target = new Date(Number(targetParts[0]), Number(targetParts[1]) - 1, 1);
    var diff = (target.getFullYear() - start.getFullYear()) * 12 + (target.getMonth() - start.getMonth());
    if (Number(t.installments || 1) > 1) return diff >= 0 && diff < Number(t.installments || 1);
    if (Number(t.recurrenceMonths || 0) > 0) return diff >= 0 && diff < Number(t.recurrenceMonths || 0);
    return diff === 0;
  }
  function cardBilledAmount(t) { return Number(t.installments || 1) > 1 ? roundMoney(Number(t.amount || 0) / Number(t.installments || 1)) : Number(t.amount || 0); }
  function cardInvoicePayment(cardId, key) { return state.invoicePayments.find(function(p){ return p.cardId === cardId && p.month === key; }); }
  function cardInvoiceTotal(cardId, key) {
    return roundMoney(sum(state.cardTransactions.filter(function(t){ return t.cardId === cardId && cardTransactionIsBilledIn(t, key); }), cardBilledAmount));
  }
  function cardAvailableLimit(card, key) {
    var used = sum(state.cardTransactions.filter(function(t){ return t.cardId === card.id && cardTransactionIsBilledIn(t, key); }), function(t){
      return t.consumeTotalLimit ? Number(t.amount || 0) : cardBilledAmount(t);
    });
    return roundMoney(Number(card.limit || 0) - used);
  }
  function cardSummary(cards, key, transactions) {
    cards = cards || [];
    transactions = transactions || [];
    var totalLimit = roundMoney(sum(cards, function(card){ return Number(card.limit || 0); }));
    var invoiceTotal = roundMoney(sum(cards, function(card){ return cardInvoiceTotal(card.id, key); }));
    var paidTotal = roundMoney(sum(cards, function(card){
      var payment = cardInvoicePayment(card.id, key);
      return payment ? Number(payment.paidAmount || 0) : 0;
    }));
    var openTotal = roundMoney(sum(cards, function(card){
      var payment = cardInvoicePayment(card.id, key);
      return Math.max(0, cardInvoiceTotal(card.id, key) - Number(payment ? payment.paidAmount || 0 : 0));
    }));
    var availableTotal = roundMoney(sum(cards, function(card){ return cardAvailableLimit(card, key); }));
    return {
      cardCount: cards.length,
      purchaseCount: transactions.length,
      purchaseTotal: roundMoney(sum(transactions, cardBilledAmount)),
      totalLimit: totalLimit,
      committedLimit: roundMoney(totalLimit - availableTotal),
      availableLimit: availableTotal,
      invoiceTotal: invoiceTotal,
      paidTotal: paidTotal,
      openTotal: openTotal
    };
  }
  function daysUntilDay(day, ref) {
    ref = ref || new Date();
    var safe = Math.max(1, Math.min(31, Number(day || 1)));
    var candidate = new Date(ref.getFullYear(), ref.getMonth(), Math.min(safe, new Date(ref.getFullYear(), ref.getMonth()+1, 0).getDate()));
    if (candidate < new Date(ref.getFullYear(), ref.getMonth(), ref.getDate())) {
      var nextMonthLast = new Date(ref.getFullYear(), ref.getMonth()+2, 0).getDate();
      candidate = new Date(ref.getFullYear(), ref.getMonth()+1, Math.min(safe, nextMonthLast));
    }
    return Math.ceil((candidate - new Date(ref.getFullYear(), ref.getMonth(), ref.getDate())) / 86400000);
  }

  function loanSchedule(loan) {
    var first = parseDateBR(loan.firstDueDate);
    var installments = Math.max(1, Number(loan.installments || 1));
    var amount = Number(loan.installmentAmount || 0);
    var paidMap = {};
    (loan.payments || []).forEach(function(p){ paidMap[p.number] = p; });
    var list = [];
    for (var i=1; i<=installments; i++) {
      var due = addMonthsDate(first, i-1);
      list.push({ number: i, dueDate: formatDateBR(due), amount: amount, paid: !!paidMap[i], paidDate: paidMap[i] ? paidMap[i].paidDate : '' });
    }
    return list;
  }
  function nextLoanInstallment(loan) {
    return loanSchedule(loan).filter(function(i){ return !i.paid; }).sort(function(a,b){ return parseDateBR(a.dueDate) - parseDateBR(b.dueDate); })[0] || null;
  }
  function loanOpenAmount(loan) {
    return roundMoney(sum(loanSchedule(loan), function(i){ return i.paid ? 0 : i.amount; }));
  }
  function nextSubscriptionDue(sub, ref) {
    ref = ref || new Date();
    var months = sub.billingCycle === 'Anual' ? 12 : sub.billingCycle === 'Trimestral' ? 3 : 1;
    var start = parseDateBR(sub.startDate);
    var dueDay = Math.max(1, Math.min(31, Number(sub.dueDay || 1)));
    var candidate = new Date(Math.max(start.getFullYear(), ref.getFullYear()), Math.max(start.getMonth(), ref.getMonth()), 1);
    candidate = new Date(candidate.getFullYear(), candidate.getMonth(), Math.min(dueDay, new Date(candidate.getFullYear(), candidate.getMonth()+1, 0).getDate()));
    while (candidate < new Date(ref.getFullYear(), ref.getMonth(), ref.getDate())) candidate = addMonthsDate(candidate, 1);
    while ((((candidate.getFullYear() - start.getFullYear()) * 12 + candidate.getMonth() - start.getMonth()) % months) !== 0) candidate = addMonthsDate(candidate, 1);
    return formatDateBR(candidate);
  }
  function subscriptionMonthlyEquivalent(sub) {
    var divisor = sub.billingCycle === 'Anual' ? 12 : sub.billingCycle === 'Trimestral' ? 3 : 1;
    return roundMoney(Number(sub.amount || 0) / divisor);
  }

  function subscriptionAmountForMonth(sub, key) {
    if (!sub || sub.active === false) return 0;
    var startKey = monthFromBR(sub.startDate);
    if (key < startKey) return 0;
    var startParts = startKey.split('-');
    var keyParts = key.split('-');
    var monthDistance = (Number(keyParts[0]) - Number(startParts[0])) * 12 + Number(keyParts[1]) - Number(startParts[1]);
    var interval = sub.billingCycle === 'Anual' ? 12 : sub.billingCycle === 'Trimestral' ? 3 : 1;
    return monthDistance % interval === 0 ? roundMoney(Number(sub.amount || 0)) : 0;
  }

  function loanInstallmentsForMonth(key) {
    var movements = [];
    state.loans.forEach(function(loan){
      loanSchedule(loan).forEach(function(installment){
        if (monthFromBR(installment.dueDate) !== key) return;
        movements.push({ loan: loan, installment: installment });
      });
    });
    return movements;
  }

  function monthlyMovements(key) {
    var movements = [];
    var salary = salaryTotals(key);
    if (salary.net) movements.push({ id:'salary-' + key, title:'Salário líquido', module:'Salário', date:'01/' + key.slice(5,7) + '/' + key.slice(0,4), amount:salary.net, type:'Receita', status:'Calculado' });
    entriesForMonth(key).forEach(function(entry){
      movements.push({ id:entry.id, title:entry.title, module:'Transações · ' + entry.category, date:entry.date, amount:Number(entry.amount || 0), type:entry.type, status:entry.status });
    });
    loanInstallmentsForMonth(key).forEach(function(item){
      movements.push({ id:item.loan.id + '-' + item.installment.number, title:item.loan.name + ' · parcela ' + item.installment.number, module:'Empréstimos', date:item.installment.dueDate, amount:Number(item.installment.amount || 0), type:item.loan.direction === 'Emprestei para alguém' ? 'Receita' : 'Despesa', status:item.installment.paid ? 'Pago' : 'Previsto' });
    });
    state.subscriptions.forEach(function(sub){
      var amount = subscriptionAmountForMonth(sub, key);
      if (!amount) return;
      movements.push({ id:'subscription-' + sub.id + '-' + key, title:sub.name, module:'Assinaturas · ' + sub.kind, date:pad(Math.max(1, Math.min(31, Number(sub.dueDay || 1)))) + '/' + key.slice(5,7) + '/' + key.slice(0,4), amount:amount, type:'Despesa', status:'Previsto' });
    });
    return movements.sort(function(a,b){ return parseDateBR(a.date) - parseDateBR(b.date); });
  }

  function dashboard(key) {
    var entries = entriesForMonth(key);
    var entryIncome = sum(entries, function(e){ return e.type === 'Receita' ? Number(e.amount || 0) : 0; });
    var entryExpense = sum(entries, function(e){ return e.type === 'Despesa' ? Number(e.amount || 0) : 0; });
    var paidIncome = sum(entries, function(e){ return e.type === 'Receita' && e.status === 'Pago' ? Number(e.amount || 0) : 0; });
    var paidExpense = sum(entries, function(e){ return e.type === 'Despesa' && e.status === 'Pago' ? Number(e.amount || 0) : 0; });
    var loanMonth = loanInstallmentsForMonth(key);
    var loanExpense = sum(loanMonth, function(item){ return item.loan.direction === 'Peguei emprestado' ? Number(item.installment.amount || 0) : 0; });
    var loanIncome = sum(loanMonth, function(item){ return item.loan.direction === 'Emprestei para alguém' ? Number(item.installment.amount || 0) : 0; });
    var paidLoanExpense = sum(loanMonth, function(item){ return item.loan.direction === 'Peguei emprestado' && item.installment.paid ? Number(item.installment.amount || 0) : 0; });
    var paidLoanIncome = sum(loanMonth, function(item){ return item.loan.direction === 'Emprestei para alguém' && item.installment.paid ? Number(item.installment.amount || 0) : 0; });
    var subscriptionsDue = sum(state.subscriptions, function(sub){
      return subscriptionAmountForMonth(sub, key);
    });
    var activeSubs = state.subscriptions.filter(function(s){ return s.active !== false; });
    var subMonthly = sum(activeSubs, subscriptionMonthlyEquivalent);
    var salary = salaryTotals(key);
    var expectedIncome = entryIncome + loanIncome;
    var expectedExpense = entryExpense + loanExpense + subscriptionsDue;
    return {
      expectedIncome: roundMoney(expectedIncome),
      expectedExpense: roundMoney(expectedExpense),
      paidIncome: roundMoney(paidIncome + paidLoanIncome),
      paidExpense: roundMoney(paidExpense + paidLoanExpense),
      expectedBalance: roundMoney(salary.net + expectedIncome - expectedExpense),
      currentBalance: roundMoney(salary.net + paidIncome + paidLoanIncome - paidExpense - paidLoanExpense),
      openInvoice: 0,
      loanBorrowedOpen: roundMoney(loanExpense),
      loanLentOpen: roundMoney(loanIncome),
      subscriptionsDue: roundMoney(subscriptionsDue),
      activeSubscriptions: activeSubs.length,
      subscriptionsMonthly: roundMoney(subMonthly),
      salaryNet: salary.net
    };
  }

  function $(id) { return document.getElementById(id); }
  function toast(message) {
    if (!root.document) return;
    var el = $('toast');
    el.textContent = message;
    el.classList.remove('hidden');
    clearTimeout(toast._t);
    toast._t = setTimeout(function(){ el.classList.add('hidden'); }, 2800);
  }
  function setScreen(id) {
    activeScreen = id;
    searchText = '';
    saveUiState();
    render();
    if ($('content')) $('content').scrollTop = 0;
  }
  function renderNav() {
    $('nav').innerHTML = screens.map(function(s){
      return '<button class="nav-btn ' + (activeScreen === s.id ? 'active' : '') + '" data-screen="' + s.id + '"><span class="nav-icon">' + s.icon + '</span><span class="nav-label">' + s.title + '</span></button>';
    }).join('');
  }
  function render() {
    if (!state) loadState();
    renderNav();
    var screen = screens.find(function(s){ return s.id === activeScreen; }) || screens[0];
    $('screen-title').textContent = screen.title;
    $('screen-subtitle').textContent = screen.subtitle;
    $('month-label').textContent = monthTitle(selectedMonth);
    var html = '';
    if (activeScreen === 'dashboard') html = renderDashboard();
    if (activeScreen === 'entries') html = renderEntries();
    if (activeScreen === 'cards') html = renderCards();
    if (activeScreen === 'salary') html = renderSalary();
    if (activeScreen === 'loans') html = renderLoans();
    if (activeScreen === 'subscriptions') html = renderSubscriptions();
    if (activeScreen === 'categories') html = renderCategories();
    if (activeScreen === 'backup') html = renderBackup();
    if (activeScreen === 'help') html = renderHelp();
    $('content').innerHTML = html;
    saveUiState();
  }
  function metricCard(label, value, cls, detail) {
    return '<div class="metric-card"><div class="metric-label">' + escapeHtml(label) + '</div><div class="metric-value ' + (cls || '') + '">' + escapeHtml(value) + '</div>' + (detail ? '<div class="card-subtitle">' + detail + '</div>' : '') + '</div>';
  }
  function empty(icon, title, text) {
    return '<div class="empty"><span class="empty-icon">' + icon + '</span><strong>' + escapeHtml(title) + '</strong><p>' + escapeHtml(text) + '</p></div>';
  }
  function dashboardHealth(d) {
    if (d.expectedBalance < 0) return { title: 'Atenção ao saldo previsto', text: 'O mês está projetado para fechar negativo. Revise despesas, assinaturas e parcelas antes do vencimento.', cls: 'red' };
    if (d.currentBalance < 0) return { title: 'Saldo atual no vermelho', text: 'Os itens já pagos deixam o mês negativo por enquanto. Confira receitas pendentes e vencimentos próximos.', cls: 'red' };
    return { title: 'Mês sob controle', text: 'O saldo previsto está positivo. Continue acompanhando transações, parcelas e assinaturas para evitar surpresas.', cls: 'green' };
  }

  function renderDashboard() {
    var d = dashboard(selectedMonth);
    var dashboardCardTransactions = state.cardTransactions.filter(function(t){ return cardTransactionIsBilledIn(t, selectedMonth); });
    var dashboardCardTotals = cardSummary(state.cards, selectedMonth, dashboardCardTransactions);
    var health = dashboardHealth(d);
    var dashboardOptions = viewOptions.dashboard;
    var movements = monthlyMovements(selectedMonth).filter(function(item){ return dashboardOptions.type === 'Todos' || item.type === dashboardOptions.type; });
    movements = sortRecords(movements, dashboardOptions.sort, {
      name:function(item){ return item.title; },
      date:function(item){ return parseDateBR(item.date); },
      amount:function(item){ return Number(item.amount || 0); }
    });
    var pending = movements.filter(function(item){ return item.status === 'Previsto'; }).slice(0, 6);
    var incomePct = d.expectedIncome + d.expectedExpense > 0 ? (d.expectedIncome / (d.expectedIncome + d.expectedExpense)) * 100 : 50;
    var pendingHtml = pending.length ? pending.map(renderMovementItem).join('') : empty('✅', 'Nada pendente', 'Não há movimentações previstas em aberto neste mês.');
    var movementsHtml = movements.length ? movements.slice(0, 10).map(renderMovementItem).join('') : empty('🧾', 'Nenhuma movimentação', 'Cadastre salário, transações, empréstimos ou assinaturas para esta competência.');
    var dueLoans = state.loans.map(function(l){ return { loan: l, next: nextLoanInstallment(l) }; }).filter(function(x){ return x.next; }).slice(0, 5);
    var loanHtml = dueLoans.length ? dueLoans.map(function(x){
      return '<div class="item"><div class="item-main"><div class="item-title">' + escapeHtml(x.loan.name) + '</div><div class="item-subtitle">Parcela ' + x.next.number + ' vence em ' + x.next.dueDate + '</div></div><strong class="' + (x.loan.direction === 'Peguei emprestado' ? 'red' : 'green') + '">' + money(x.next.amount) + '</strong></div>';
    }).join('') : '<div class="item"><span class="muted">Nenhuma parcela em aberto cadastrada.</span></div>';
    return ''+
      '<div class="dashboard-hero"><div><h2>' + escapeHtml(health.title) + '</h2><p class="hero-copy">' + escapeHtml(health.text) + '</p><div class="status-strip"><span class="pill green">Recebido ' + money(d.paidIncome) + '</span><span class="pill red">Pago ' + money(d.paidExpense) + '</span></div></div><div class="hero-value"><div class="metric-label">Saldo previsto</div><div class="metric-value ' + health.cls + '">' + money(d.expectedBalance) + '</div><div class="card-subtitle">' + monthTitle(selectedMonth) + '</div></div></div>' +
      '<div class="grid grid-4">' +
        metricCard('Saldo previsto', money(d.expectedBalance), d.expectedBalance >= 0 ? 'green' : 'red', 'Salário + receitas − despesas do mês') +
        metricCard('Salário líquido', money(d.salaryNet), d.salaryNet >= 0 ? 'green' : 'red', 'Proventos e descontos incluídos') +
        metricCard('Entradas previstas', money(d.expectedIncome), 'green', 'Além do salário') +
        metricCard('Saídas previstas', money(d.expectedExpense), 'red', 'Transações, parcelas e assinaturas') +
      '</div>'+
      '<div class="grid grid-3" style="margin-top:16px">' +
        metricCard('Parcelas a pagar', money(d.loanBorrowedOpen), 'red') +
        metricCard('Parcelas a receber', money(d.loanLentOpen), 'green') +
        metricCard('Assinaturas do mês', money(d.subscriptionsDue), 'yellow', d.activeSubscriptions + ' ativa(s)') +
      '</div>'+
      '<div class="grid grid-3" style="margin-top:16px">' +
        metricCard('Limite total dos cartões', money(dashboardCardTotals.totalLimit), 'yellow') +
        metricCard('Disponível nos cartões', money(dashboardCardTotals.availableLimit), dashboardCardTotals.availableLimit >= 0 ? 'green' : 'red') +
        metricCard('Faturas dos cartões', money(dashboardCardTotals.invoiceTotal), 'yellow') +
      '</div>'+
      '<div class="grid grid-2" style="margin-top:16px">' +
        '<div class="card"><div class="card-header"><div><div class="card-title">Movimento do mês</div><div class="card-subtitle">Receitas x despesas previstas</div></div></div><div class="chartbar"><span class="income" style="width:' + incomePct + '%"></span><span class="expense" style="width:' + (100-incomePct) + '%"></span></div><div class="row-between" style="margin-top:12px"><span class="green">' + money(d.expectedIncome) + '</span><span class="red">' + money(d.expectedExpense) + '</span></div></div>' +
        '<div class="card"><div class="card-header"><div><div class="card-title">Atalhos</div><div class="card-subtitle">Cadastros rápidos integrados ao cálculo</div></div></div><div class="row wrap"><button class="primary-btn" data-action="new-entry">Nova transação</button><button class="success-btn" data-action="new-loan">Novo empréstimo</button><button class="secondary-btn" data-action="new-subscription">Assinatura</button><button class="yellow-btn" data-screen="salary">Salário</button></div></div>' +
      '</div>'+
      '<div class="card" style="margin-top:16px"><div class="card-header"><div><div class="card-title">Movimentações consolidadas</div><div class="card-subtitle">Tudo o que foi lançado nos módulos desta competência, exceto cartões</div></div></div>' + filterBar(
        filterSelect('dashboard-type-filter','Mostrar',[{value:'Todos',label:'Todas as movimentações'},{value:'Receita',label:'Somente entradas'},{value:'Despesa',label:'Somente saídas'}],dashboardOptions.type) +
        filterSelect('dashboard-sort','Ordenar por',[{value:'date-asc',label:'Data: mais antiga'},{value:'date-desc',label:'Data: mais recente'},{value:'amount-desc',label:'Maior valor'},{value:'amount-asc',label:'Menor valor'},{value:'name-asc',label:'Nome: A–Z'},{value:'name-desc',label:'Nome: Z–A'}],dashboardOptions.sort)
      ) + '<div class="list">' + movementsHtml + '</div></div>' +
      '<div class="grid grid-2" style="margin-top:16px">' +
        '<div class="card"><div class="card-header"><div><div class="card-title">Pendências do período</div><div class="card-subtitle">Movimentações previstas ainda não pagas</div></div><button class="secondary-btn" data-screen="entries">Ver transações</button></div><div class="list">' + pendingHtml + '</div></div>' +
        '<div class="card"><div class="card-header"><div><div class="card-title">Próximas parcelas</div><div class="card-subtitle">Empréstimos cadastrados</div></div><button class="secondary-btn" data-screen="loans">Ver</button></div><div class="list">' + loanHtml + '</div></div>' +
      '</div>';
  }

  function renderMovementItem(item) {
    var amountCls = item.type === 'Receita' ? 'green' : 'red';
    var statusCls = item.status === 'Pago' || item.status === 'Calculado' ? 'green' : 'yellow';
    var signal = item.type === 'Receita' ? '+ ' : '− ';
    return '<div class="item"><div class="item-main"><div class="item-title">' + escapeHtml(item.title) + '</div><div class="item-subtitle">' + escapeHtml(item.module) + ' · ' + escapeHtml(item.date) + ' · <span class="' + statusCls + '">' + escapeHtml(item.status) + '</span></div></div><strong class="' + amountCls + '">' + signal + money(item.amount) + '</strong></div>';
  }

  function renderEntryItem(e) {
    var amountCls = e.type === 'Receita' ? 'green' : 'red';
    var statusCls = e.status === 'Pago' ? 'green' : 'yellow';
    return '<div class="item"><div class="item-main"><div class="item-title">' + escapeHtml(e.title) + '</div><div class="item-subtitle">' + escapeHtml(e.category) + ' · ' + escapeHtml(e.date) + ' · <span class="' + statusCls + '">' + escapeHtml(e.status) + '</span>' + escapeHtml(recurrenceSummary(e)) + '</div></div><div class="row"><strong class="' + amountCls + '">' + money(e.amount) + '</strong><button class="secondary-btn" data-action="toggle-entry" data-id="' + e.id + '">' + (e.status === 'Pago' ? 'Estornar' : 'Baixar') + '</button><button class="secondary-btn" data-action="edit-entry" data-id="' + e.id + '">Editar</button><button class="danger-btn" data-action="delete-entry" data-id="' + e.id + '">Excluir</button></div></div>';
  }
  function renderEntries() {
    var options = viewOptions.entries;
    var list = entriesForMonth(selectedMonth).filter(function(e){
      var q = normalizeText(searchText);
      return (!q || normalizeText(e.title + ' ' + e.category + ' ' + e.notes).indexOf(q) >= 0) &&
        (options.type === 'Todos' || e.type === options.type) &&
        (options.status === 'Todos' || e.status === options.status);
    });
    list = sortRecords(list, options.sort, {
      name:function(entry){ return entry.title; },
      date:function(entry){ return parseDateBR(entry.date); },
      amount:function(entry){ return Number(entry.amount || 0); },
      category:function(entry){ return entry.category; }
    });
    return '<div class="toolbar"><div class="toolbar-left"><input class="search" id="search-box" placeholder="Pesquisar transação..." value="' + escapeHtml(searchText) + '"></div><div class="toolbar-right"><button class="primary-btn" data-action="new-entry">+ Nova transação</button></div></div>'+ filterBar(
      filterSelect('entries-type-filter','Tipo',[{value:'Todos',label:'Receitas e despesas'},{value:'Receita',label:'Receitas'},{value:'Despesa',label:'Despesas'}],options.type) +
      filterSelect('entries-status-filter','Situação',[{value:'Todos',label:'Todas'},{value:'Previsto',label:'Previstas'},{value:'Pago',label:'Pagas'}],options.status) +
      filterSelect('entries-sort','Ordenar por',[{value:'date-asc',label:'Data: mais antiga'},{value:'date-desc',label:'Data: mais recente'},{value:'amount-desc',label:'Maior valor'},{value:'amount-asc',label:'Menor valor'},{value:'name-asc',label:'Nome: A–Z'},{value:'category-asc',label:'Categoria: A–Z'}],options.sort)
    ) +
      '<div class="card"><div class="list">' + (list.length ? list.map(renderEntryItem).join('') : empty('🧾','Nenhuma transação','Cadastre receitas ou despesas para este mês.')) + '</div></div>';
  }

  function cardColorClass(name) {
    var n = normalizeText(name);
    if (n.indexOf('roxo') >= 0) return 'roxo';
    if (n.indexOf('azul') >= 0) return 'azul';
    if (n.indexOf('verde') >= 0) return 'verde';
    if (n.indexOf('vermelho') >= 0) return 'vermelho';
    return '';
  }
  function renderCards() {
    var options = viewOptions.cards;
    var cards = state.cards.filter(function(c){
      var open = Math.max(0, cardInvoiceTotal(c.id, selectedMonth) - Number((cardInvoicePayment(c.id, selectedMonth) || {}).paidAmount || 0));
      return options.status === 'Todos' || (options.status === 'Em aberto' ? open > 0 : open <= 0);
    });
    cards = sortRecords(cards, options.sort, {
      name:function(c){ return c.name; },
      invoice:function(c){ return cardInvoiceTotal(c.id, selectedMonth); },
      limit:function(c){ return Number(c.limit || 0); },
      available:function(c){ return cardAvailableLimit(c, selectedMonth); },
      due:function(c){ return Number(c.dueDay || 0); }
    });
    var cardsHtml = cards.length ? cards.map(function(c){
      var total = cardInvoiceTotal(c.id, selectedMonth);
      var paid = cardInvoicePayment(c.id, selectedMonth);
      var paidAmount = paid ? Number(paid.paidAmount || 0) : 0;
      var open = Math.max(0, total - paidAmount);
      var available = cardAvailableLimit(c, selectedMonth);
      return '<div class="card"><div class="card-visual ' + cardColorClass(c.colorName) + '"><div class="row-between"><strong>' + escapeHtml(c.name) + '</strong><span class="pill yellow">' + escapeHtml(c.brandName || 'Cartão') + '</span></div><div style="font-size:22px;margin-top:28px;letter-spacing:2px">•••• •••• •••• ' + escapeHtml(c.lastDigits || '0000') + '</div><div class="row-between" style="margin-top:22px"><span>Limite ' + money(c.limit) + '</span><span>Venc. dia ' + escapeHtml(c.dueDay) + '</span></div></div><div class="grid grid-4" style="margin-top:12px">' + metricCard('Limite total', money(c.limit), 'muted') + metricCard('Fatura', money(total), 'yellow') + metricCard('Aberto', money(open), open > 0 ? 'red' : 'green') + metricCard('Disponível', money(available), available >= 0 ? 'green' : 'red') + '</div><div class="row wrap" style="margin-top:12px"><button class="yellow-btn" data-action="new-card-transaction" data-card="' + c.id + '">Compra</button><button class="success-btn" data-action="pay-invoice" data-id="' + c.id + '">Pagar fatura</button><button class="secondary-btn" data-action="edit-card" data-id="' + c.id + '">Editar</button><button class="danger-btn" data-action="delete-card" data-id="' + c.id + '">Excluir</button></div></div>';
    }).join('') : empty('💳','Nenhum cartão','Cadastre um cartão para controlar compras e faturas.');
    var monthTransactions = state.cardTransactions.filter(function(t){
      return cardTransactionIsBilledIn(t, selectedMonth) && (options.purchaseCard === 'Todos' || t.cardId === options.purchaseCard);
    });
    monthTransactions = sortRecords(monthTransactions, options.purchaseSort, {
      name:function(t){ return t.title; },
      amount:function(t){ return cardBilledAmount(t); },
      date:function(t){ return parseDateBR(t.date); }
    });
    var transHtml = monthTransactions.length ? monthTransactions.map(function(t){
      var card = state.cards.find(function(c){ return c.id === t.cardId; });
      return '<div class="invoice-line"><div><strong>' + escapeHtml(t.title) + '</strong><div class="item-subtitle">' + escapeHtml(card ? card.name : 'Cartão removido') + ' · ' + escapeHtml(t.category) + ' · ' + escapeHtml(t.date) + (Number(t.installments || 1) > 1 ? ' · ' + t.installments + 'x' : '') + '</div></div><div class="row"><strong class="red">' + money(cardBilledAmount(t)) + '</strong><button class="secondary-btn" data-action="edit-card-transaction" data-id="' + t.id + '">Editar</button><button class="danger-btn" data-action="delete-card-transaction" data-id="' + t.id + '">Excluir</button></div></div>';
    }).join('') : '<div class="item"><span class="muted">Nenhuma compra faturada neste mês.</span></div>';
    var summary = cardSummary(cards, selectedMonth, monthTransactions);
    var summaryHtml = '<div class="card card-summary" style="margin-bottom:16px"><div class="card-header"><div><div class="card-title">Resumo consolidado de ' + monthTitle(selectedMonth) + '</div><div class="card-subtitle">Totais dos cartões e compras apresentados pelos filtros atuais</div></div></div><div class="grid grid-4">' +
      metricCard('Cartões exibidos', String(summary.cardCount), 'muted') +
      metricCard('Limite total', money(summary.totalLimit), 'yellow') +
      metricCard('Limite comprometido', money(summary.committedLimit), summary.committedLimit > summary.totalLimit ? 'red' : 'yellow') +
      metricCard('Limite disponível', money(summary.availableLimit), summary.availableLimit >= 0 ? 'green' : 'red') +
      metricCard('Faturas do mês', money(summary.invoiceTotal), 'yellow') +
      metricCard('Valores pagos', money(summary.paidTotal), 'green') +
      metricCard('Valores em aberto', money(summary.openTotal), summary.openTotal > 0 ? 'red' : 'green') +
      metricCard('Compras exibidas', summary.purchaseCount + ' · ' + money(summary.purchaseTotal), 'muted') +
    '</div></div>';
    var cardChoices = [{value:'Todos',label:'Todos os cartões'}].concat(state.cards.map(function(c){ return {value:c.id,label:c.name}; }));
    return summaryHtml + '<div class="toolbar"><div class="toolbar-left"><button class="primary-btn" data-action="new-card">+ Novo cartão</button><button class="yellow-btn" data-action="new-card-transaction">+ Nova compra</button></div></div>' + filterBar(
      filterSelect('cards-status-filter','Situação da fatura',[{value:'Todos',label:'Todas as situações'},{value:'Em aberto',label:'Com valor em aberto'},{value:'Quitados',label:'Sem valor em aberto'}],options.status) +
      filterSelect('cards-sort','Ordenar cartões',[{value:'name-asc',label:'Nome: A–Z'},{value:'name-desc',label:'Nome: Z–A'},{value:'limit-desc',label:'Maior limite total'},{value:'limit-asc',label:'Menor limite total'},{value:'invoice-desc',label:'Maior fatura'},{value:'invoice-asc',label:'Menor fatura'},{value:'available-desc',label:'Maior limite disponível'},{value:'due-asc',label:'Vencimento mais próximo'}],options.sort)
    ) + '<div class="grid grid-2">' + cardsHtml + '</div><div class="card" style="margin-top:16px"><div class="card-header"><div><div class="card-title">Compras na fatura de ' + monthTitle(selectedMonth) + '</div><div class="card-subtitle">Parcelas e recorrências que caem no mês</div></div></div>' + filterBar(
      filterSelect('cards-purchase-card-filter','Cartão',cardChoices,options.purchaseCard) +
      filterSelect('cards-purchase-sort','Ordenar compras',[{value:'date-desc',label:'Data: mais recente'},{value:'date-asc',label:'Data: mais antiga'},{value:'amount-desc',label:'Maior valor'},{value:'amount-asc',label:'Menor valor'},{value:'name-asc',label:'Nome: A–Z'},{value:'name-desc',label:'Nome: Z–A'}],options.purchaseSort)
    ) + transHtml + '</div>';
  }

  function renderSalary() {
    var t = salaryTotals(selectedMonth), r = t.record;
    var options = viewOptions.salary;
    var salaryItems = (r.items || []).filter(function(item){ return options.type === 'Todos' || item.type === options.type; });
    salaryItems = sortRecords(salaryItems, options.sort, {
      name:function(item){ return item.name; },
      amount:function(item){ return salaryItemAmount(item, r.grossSalary); },
      type:function(item){ return item.type; }
    });
    var itemsHtml = salaryItems.length ? salaryItems.map(function(i){
      var amount = salaryItemAmount(i, r.grossSalary);
      var validity = salaryItemIsLoan(i) ? ' · vigência: ' + monthTitle(i.startMonth) + ' a ' + monthTitle(i.endMonth) : (i.fixedMonthly ? ' · fixo mensal' : '');
      return '<div class="item"><div class="item-main"><div class="item-title">' + escapeHtml(i.name) + '</div><div class="item-subtitle">' + escapeHtml(i.type) + ' · ' + escapeHtml(i.valueMode) + (i.valueMode === 'Percentual' ? ': ' + i.value + '%' : '') + validity + '</div></div><div class="row"><strong class="' + (i.type === 'Recebimento' ? 'green' : 'red') + '">' + money(amount) + '</strong><button class="secondary-btn" data-action="edit-salary-item" data-id="' + i.id + '">Editar</button><button class="danger-btn" data-action="delete-salary-item" data-id="' + i.id + '">Excluir</button></div></div>';
    }).join('') : empty('💵','Nenhum item','Cadastre proventos ou descontos do salário.');
    return '<div class="grid grid-5">' + metricCard('Salário bruto', money(r.grossSalary), 'yellow') + metricCard('Proventos', money(t.earnings), 'green') + metricCard('Descontos', money(t.deductions), 'red') + metricCard('Empréstimos CLT', money(t.loanDeductions), 'red') + metricCard('Líquido', money(t.net), t.net >= 0 ? 'green' : 'red') + '</div><div class="toolbar" style="margin-top:16px"><div class="toolbar-left"><button class="primary-btn" data-action="set-salary">Definir salário</button><button class="success-btn" data-action="new-salary-item">+ Provento, desconto ou empréstimo</button></div></div>' + filterBar(
      filterSelect('salary-type-filter','Mostrar',[{value:'Todos',label:'Todos os itens'},{value:'Recebimento',label:'Somente recebimentos'},{value:'Desconto',label:'Somente descontos'},{value:'Empréstimo CLT',label:'Somente empréstimos CLT'}],options.type) +
      filterSelect('salary-sort','Ordenar por',[{value:'name-asc',label:'Nome: A–Z'},{value:'name-desc',label:'Nome: Z–A'},{value:'amount-desc',label:'Maior valor'},{value:'amount-asc',label:'Menor valor'},{value:'type-asc',label:'Tipo'}],options.sort)
    ) + '<div class="card"><div class="list">' + itemsHtml + '</div></div>';
  }

  function renderLoans() {
    var options = viewOptions.loans;
    var loans = state.loans.filter(function(loan){
      var isPaid = !nextLoanInstallment(loan);
      return (options.direction === 'Todos' || loan.direction === options.direction) &&
        (options.status === 'Todos' || (options.status === 'Quitados' ? isPaid : !isPaid));
    });
    loans = sortRecords(loans, options.sort, {
      name:function(loan){ return loan.name; },
      amount:function(loan){ return loanOpenAmount(loan); },
      installment:function(loan){ return Number(loan.installmentAmount || 0); },
      due:function(loan){ var next=nextLoanInstallment(loan); return next ? parseDateBR(next.dueDate) : new Date(8640000000000000); }
    });
    var html = loans.length ? loans.map(function(l){
      var sched = loanSchedule(l);
      var paidCount = sched.filter(function(i){ return i.paid; }).length;
      var next = nextLoanInstallment(l);
      var directionCls = l.direction === 'Peguei emprestado' ? 'red' : 'green';
      return '<div class="card"><div class="card-header"><div><div class="card-title">' + escapeHtml(l.name) + '</div><div class="card-subtitle"><span class="pill ' + directionCls + '">' + escapeHtml(l.direction) + '</span> <span class="pill">' + paidCount + '/' + l.installments + ' pagas</span></div></div><strong class="' + directionCls + '">' + money(loanOpenAmount(l)) + '</strong></div><div class="grid grid-3">' + metricCard('Parcela', money(l.installmentAmount), 'yellow') + metricCard('Principal', money(l.principalAmount), 'muted') + metricCard('Próxima', next ? next.dueDate : 'Quitado', next ? 'yellow' : 'green') + '</div><div class="row wrap" style="margin-top:12px"><button class="success-btn" data-action="pay-next-loan" data-id="' + l.id + '" ' + (!next ? 'disabled' : '') + '>Baixar próxima</button><button class="secondary-btn" data-action="loan-details" data-id="' + l.id + '">Parcelas</button><button class="secondary-btn" data-action="edit-loan" data-id="' + l.id + '">Editar</button><button class="danger-btn" data-action="delete-loan" data-id="' + l.id + '">Excluir</button></div></div>';
    }).join('') : empty('🏦','Nenhum empréstimo','Cadastre empréstimos recebidos ou feitos para terceiros.');
    return '<div class="toolbar"><div class="toolbar-left"><button class="primary-btn" data-action="new-loan">+ Novo empréstimo</button></div></div>' + filterBar(
      filterSelect('loans-direction-filter','Direção',[{value:'Todos',label:'Todos os empréstimos'},{value:'Peguei emprestado',label:'Valores a pagar'},{value:'Emprestei para alguém',label:'Valores a receber'}],options.direction) +
      filterSelect('loans-status-filter','Situação',[{value:'Todos',label:'Todos'},{value:'Em aberto',label:'Em aberto'},{value:'Quitados',label:'Quitados'}],options.status) +
      filterSelect('loans-sort','Ordenar por',[{value:'name-asc',label:'Nome: A–Z'},{value:'name-desc',label:'Nome: Z–A'},{value:'amount-desc',label:'Maior saldo'},{value:'amount-asc',label:'Menor saldo'},{value:'installment-desc',label:'Maior parcela'},{value:'due-asc',label:'Próximo vencimento'}],options.sort)
    ) + '<div class="grid grid-2">' + html + '</div>';
  }

  function renderSubscriptions() {
    var options = viewOptions.subscriptions;
    var subscriptions = state.subscriptions.filter(function(sub){
      return (options.status === 'Todos' || (options.status === 'Ativas' ? sub.active !== false : sub.active === false)) &&
        (options.cycle === 'Todos' || sub.billingCycle === options.cycle);
    });
    subscriptions = sortRecords(subscriptions, options.sort, {
      name:function(sub){ return sub.name; },
      amount:function(sub){ return Number(sub.amount || 0); },
      due:function(sub){ return parseDateBR(nextSubscriptionDue(sub)); },
      cycle:function(sub){ return sub.billingCycle; }
    });
    var html = subscriptions.length ? subscriptions.map(function(s){
      var due = nextSubscriptionDue(s);
      return '<div class="card"><div class="card-header"><div><div class="card-title">' + escapeHtml(s.name) + '</div><div class="card-subtitle"><span class="pill yellow">' + escapeHtml(s.kind) + '</span> <span class="pill ' + (s.active !== false ? 'green' : '') + '">' + (s.active !== false ? 'Ativa' : 'Pausada') + '</span></div></div><strong class="yellow">' + money(s.amount) + '</strong></div><div class="grid grid-3">' + metricCard('Ciclo', s.billingCycle, 'muted') + metricCard('Equiv. mês', money(subscriptionMonthlyEquivalent(s)), 'yellow') + metricCard('Próximo venc.', due, 'green') + '</div><div class="row wrap" style="margin-top:12px"><button class="secondary-btn" data-action="toggle-subscription" data-id="' + s.id + '">' + (s.active !== false ? 'Pausar' : 'Ativar') + '</button><button class="secondary-btn" data-action="edit-subscription" data-id="' + s.id + '">Editar</button><button class="danger-btn" data-action="delete-subscription" data-id="' + s.id + '">Excluir</button></div></div>';
    }).join('') : empty('🔁','Nenhuma assinatura','Cadastre aplicativos, jogos, streaming e recorrências.');
    return '<div class="toolbar"><div class="toolbar-left"><button class="primary-btn" data-action="new-subscription">+ Nova assinatura</button></div></div>' + filterBar(
      filterSelect('subscriptions-status-filter','Situação',[{value:'Todos',label:'Ativas e pausadas'},{value:'Ativas',label:'Ativas'},{value:'Pausadas',label:'Pausadas'}],options.status) +
      filterSelect('subscriptions-cycle-filter','Ciclo',[{value:'Todos',label:'Todos os ciclos'},{value:'Mensal',label:'Mensal'},{value:'Trimestral',label:'Trimestral'},{value:'Anual',label:'Anual'}],options.cycle) +
      filterSelect('subscriptions-sort','Ordenar por',[{value:'name-asc',label:'Nome: A–Z'},{value:'name-desc',label:'Nome: Z–A'},{value:'amount-desc',label:'Maior valor'},{value:'amount-asc',label:'Menor valor'},{value:'due-asc',label:'Próximo vencimento'},{value:'cycle-asc',label:'Ciclo'}],options.sort)
    ) + '<div class="grid grid-3">' + html + '</div>';
  }

  function renderCategories() {
    var labels = { income:'Receitas', expense:'Despesas', card:'Cartão', salary:'Salário', loan:'Empréstimos' };
    var html = Object.keys(labels).map(function(k){
      var categories = sortRecords(state.categories[k], viewOptions.categories.sort, { name:function(name){ return name; } });
      var rows = categories.map(function(name){
        return '<div class="item"><div class="item-main"><div class="item-title">' + escapeHtml(name) + '</div></div><button class="danger-btn" data-action="delete-category" data-module="' + k + '" data-name="' + escapeHtml(name) + '">Excluir</button></div>';
      }).join('');
      return '<div class="card"><div class="card-header"><div><div class="card-title">' + labels[k] + '</div><div class="card-subtitle">' + state.categories[k].length + ' categoria(s)</div></div><button class="primary-btn" data-action="new-category" data-module="' + k + '">Adicionar</button></div><div class="list">' + rows + '</div></div>';
    }).join('');
    return filterBar(filterSelect('categories-sort','Ordenar categorias',[{value:'name-asc',label:'Nome: A–Z'},{value:'name-desc',label:'Nome: Z–A'}],viewOptions.categories.sort)) + '<div class="grid grid-2">' + html + '</div>';
  }

  function renderBackup() {
    var count = state.entries.length + state.cards.length + state.cardTransactions.length + state.loans.length + state.subscriptions.length + state.salaryRecords.length;
    return '<div class="grid grid-2"><div class="card"><div class="card-title">Backup local</div><p class="card-subtitle" style="margin:8px 0 16px">O aplicativo salva os dados localmente neste computador. Use Exportar para guardar uma cópia JSON.</p><div class="grid grid-2">' + metricCard('Registros', String(count), 'yellow') + metricCard('Versão', state.version || '1.3.0-windows', 'muted') + '</div><div class="row wrap" style="margin-top:16px"><button class="success-btn" data-action="export-backup">Exportar backup</button><button class="yellow-btn" data-action="import-backup">Importar backup</button><button class="danger-btn" data-action="reset-data">Zerar dados</button></div></div><div class="card"><div class="card-title">Integração financeira</div><p class="card-subtitle" style="margin-top:8px">O painel consolida transações, salário, parcelas de empréstimos e assinaturas por competência. Cartões ficam fora dos cálculos deste aplicativo e os registros antigos permanecem preservados no backup.</p><p class="card-subtitle" style="margin-top:12px">Para trocar de computador, exporte o arquivo JSON e importe-o na nova instalação.</p></div></div>';
  }

  function renderHelp() {
    return '<div class="help-intro card"><span class="pill yellow">GUIA DO SISTEMA</span><h2>Como usar o RB Gestão Financeira</h2><p>Este tutorial explica o fluxo completo do aplicativo. Comece cadastrando o salário e depois registre as demais movimentações. Consulte sempre o mês exibido no topo da tela.</p></div>' +
      '<div class="help-grid">' +
        helpSection('1','Primeiros passos','Prepare o sistema para começar','<ol><li>Abra <strong>Salário</strong> e defina o salário bruto.</li><li>Cadastre recebimentos, descontos e empréstimos CLT.</li><li>Registre receitas e despesas em <strong>Transações</strong>.</li><li>Cadastre cartões, empréstimos e assinaturas nos módulos correspondentes.</li></ol>') +
        helpSection('2','Mês e navegação','Consulte cada competência','<ul><li>Use as setas no topo para avançar ou voltar um mês.</li><li>Clique no nome do mês para retornar ao próximo mês em relação à data atual.</li><li>Os lançamentos e totais acompanham o mês selecionado.</li><li>Ao pressionar <strong>F5</strong>, a tela, o mês, os filtros e a ordenação são preservados.</li></ul>') +
        helpSection('3','Início e saldo previsto','Entenda o painel financeiro','<ul><li>O saldo considera salário líquido, receitas, despesas, empréstimos e assinaturas.</li><li>Entradas aumentam o saldo; saídas e descontos reduzem o saldo.</li><li>Os três totais de cartões servem para consulta e não alteram o saldo previsto.</li><li>As movimentações consolidadas mostram origem, data, situação e valor.</li></ul>') +
        helpSection('4','Transações','Receitas e despesas do dia a dia','<ul><li>Clique em <strong>Nova transação</strong> e informe descrição, valor, tipo, categoria, situação e data.</li><li>Use <strong>Previsto</strong> para valores ainda não realizados e <strong>Pago</strong> para valores concluídos.</li><li>A recorrência mensal cria lançamentos nos meses seguintes.</li><li>Use <strong>Baixar</strong>, <strong>Estornar</strong>, <strong>Editar</strong> ou <strong>Excluir</strong> conforme necessário.</li></ul>') +
        helpSection('5','Cartões','Limites, compras e faturas','<ul><li>Cadastre o cartão com limite, fechamento, vencimento, cor e bandeira.</li><li>Em <strong>Nova compra</strong>, escolha cartão, categoria, data, parcelas e recorrência.</li><li>O sistema calcula limite total, comprometido, disponível, fatura e valor em aberto.</li><li>Use <strong>Pagar fatura</strong> para registrar pagamento integral, parcial ou parcelado.</li><li>Compras e faturas não entram no cálculo do saldo financeiro.</li></ul>') +
        helpSection('6','Salário e empréstimos CLT','Histórico mensal do salário líquido','<ul><li><strong>Recebimento</strong> adiciona comissão, bônus ou outro provento.</li><li><strong>Desconto</strong> registra INSS, faltas e demais deduções.</li><li><strong>Empréstimo CLT</strong> solicita início e fim do contrato e desconta somente durante a vigência.</li><li>Valores podem ser fixos ou percentuais sobre o salário bruto.</li><li>O salário permanece válido nos meses seguintes até outro ser cadastrado.</li></ul>') +
        helpSection('7','Empréstimos','Parcelas a pagar ou receber','<ul><li>Escolha <strong>Peguei emprestado</strong> para valores a pagar.</li><li>Escolha <strong>Emprestei para alguém</strong> para valores a receber.</li><li>Informe principal, parcela, quantidade, primeiro vencimento e juros.</li><li>Use <strong>Baixar próxima</strong> e consulte todo o cronograma em <strong>Parcelas</strong>.</li></ul>') +
        helpSection('8','Assinaturas','Serviços e cobranças recorrentes','<ul><li>Cadastre nome, tipo, valor, ciclo, vencimento e data inicial.</li><li>O ciclo pode ser mensal, trimestral ou anual.</li><li>A cobrança entra no cálculo apenas quando for devida no mês selecionado.</li><li>Use <strong>Pausar</strong> para interromper temporariamente sem excluir.</li></ul>') +
        helpSection('9','Filtros, ordenação e categorias','Encontre exatamente o que precisa','<ul><li>Use filtros por tipo, situação, direção, ciclo ou cartão.</li><li>Ordene por nome, data, valor, vencimento, fatura ou limite.</li><li>Em <strong>Categorias</strong>, crie nomes personalizados para cada módulo.</li><li>Excluir uma categoria não apaga lançamentos que já a utilizam.</li></ul>') +
        helpSection('10','Backup e segurança','Proteja seus dados','<ul><li>Use <strong>Exportar backup</strong> regularmente e guarde o JSON em local seguro.</li><li>Use <strong>Importar backup</strong> para restaurar dados ou trocar de computador.</li><li><strong>Zerar dados</strong> remove todos os registros e deve ser usado com cuidado.</li><li>A desinstalação não apaga automaticamente os dados locais.</li></ul>') +
      '</div><div class="help-callout card"><strong>Dica:</strong> antes de excluir muitos registros ou zerar a base, exporte um backup para poder recuperar as informações.</div>';
  }
  function helpSection(number, title, subtitle, content) {
    return '<section class="card help-card"><div class="help-heading"><span class="help-number">' + number + '</span><div><div class="card-title">' + title + '</div><div class="card-subtitle">' + subtitle + '</div></div></div><div class="help-list">' + content + '</div></section>';
  }

  function field(label, name, type, value, attrs) {
    attrs = attrs || '';
    return '<div class="field"><label for="' + name + '">' + label + '</label><input class="input" id="' + name + '" name="' + name + '" type="' + type + '" value="' + escapeHtml(value || '') + '" ' + attrs + '></div>';
  }
  function selectField(label, name, options, selected) {
    return '<div class="field"><label for="' + name + '">' + label + '</label><select class="select" id="' + name + '" name="' + name + '">' + options.map(function(o){ return '<option value="' + escapeHtml(o) + '" ' + (o === selected ? 'selected' : '') + '>' + escapeHtml(o) + '</option>'; }).join('') + '</select></div>';
  }

  function selectObjectField(label, name, options, selected) {
    return '<div class="field"><label for="' + name + '">' + label + '</label><select class="select" id="' + name + '" name="' + name + '">' + options.map(function(o){ return '<option value="' + escapeHtml(o.value) + '" ' + (o.value === selected ? 'selected' : '') + '>' + escapeHtml(o.label) + '</option>'; }).join('') + '</select></div>';
  }
  function textareaField(label, name, value) {
    return '<div class="field form-full"><label for="' + name + '">' + label + '</label><textarea class="textarea" id="' + name + '" name="' + name + '">' + escapeHtml(value || '') + '</textarea></div>';
  }
  function showModal(title, desc, body, onSubmit, size) {
    $('modal-root').innerHTML = '<div class="modal-backdrop"><div class="modal ' + (size || '') + '"><h2>' + escapeHtml(title) + '</h2><p class="modal-desc">' + escapeHtml(desc || '') + '</p><form id="modal-form">' + body + '<div class="actions"><button type="button" class="secondary-btn" data-action="close-modal">Cancelar</button><button type="submit" class="primary-btn">Salvar</button></div></form></div></div>';
    $('modal-form').onsubmit = function(ev){ ev.preventDefault(); onSubmit(new FormData(ev.target)); };
  }
  function closeModal() { $('modal-root').innerHTML = ''; }

  function openEntryForm(entry) {
    entry = entry || { id:'', title:'', amount:'', type:'Despesa', category: state.categories.expense[0], date: todayBR(), status:'Previsto', notes:'' };
    var cats = entry.type === 'Receita' ? state.categories.income : state.categories.expense;
    var recurrenceFields = entry.id ? '' : selectField('Recorrência', 'recurrenceMode', ['Somente este mês','Mensal fixa'], 'Somente este mês') + field('Quantidade de meses', 'recurrenceMonths', 'number', '12', 'min="1" max="360"');
    var body = '<div class="form-grid">' +
      field('Descrição', 'title', 'text', entry.title, 'required') + field('Valor', 'amount', 'text', entry.amount ? money(entry.amount).replace('R$','').trim() : '', 'required') +
      selectField('Tipo', 'type', ['Receita','Despesa'], entry.type) + selectField('Status', 'status', ['Previsto','Pago'], entry.status) +
      selectField('Categoria', 'category', cats, entry.category) + field('Data', 'date', 'date', dateInputFromBR(entry.date), 'required') + recurrenceFields + textareaField('Observação', 'notes', entry.notes) + '</div>';
    showModal(entry.id ? 'Editar transação' : 'Nova transação', 'Informe os dados do lançamento.', body, function(fd){
      var type = fd.get('type');
      var obj = { id: entry.id || uid(), title: fd.get('title').trim(), amount: parseMoney(fd.get('amount')), type: type, category: fd.get('category'), date: dateBRFromInput(fd.get('date')), status: fd.get('status'), notes: fd.get('notes') || '' };
      if (!obj.title || obj.amount <= 0) return toast('Informe descrição e valor maior que zero.');
      var idx = state.entries.findIndex(function(e){ return e.id === obj.id; });
      if (idx >= 0) {
        var existing = state.entries[idx];
        obj.recurringGroupId = existing.recurringGroupId;
        obj.recurringIndex = existing.recurringIndex;
        obj.recurringTotal = existing.recurringTotal;
        obj.recurringFrequency = existing.recurringFrequency;
        state.entries[idx] = obj;
        saveState(); closeModal(); render(); toast('Transação salva.');
        return;
      }
      var months = fd.get('recurrenceMode') === 'Mensal fixa' ? Number(fd.get('recurrenceMonths') || 1) : 1;
      var created = buildRecurringEntries(obj, months);
      state.entries = state.entries.concat(created);
      saveState(); closeModal(); render(); toast(created.length > 1 ? created.length + ' transações mensais criadas.' : 'Transação salva.');
    });
    var typeEl = $('type');
    typeEl.onchange = function(){
      var catEl = $('category');
      var list = typeEl.value === 'Receita' ? state.categories.income : state.categories.expense;
      catEl.innerHTML = list.map(function(c){ return '<option value="' + escapeHtml(c) + '">' + escapeHtml(c) + '</option>'; }).join('');
    };
    var recurrenceModeEl = $('recurrenceMode');
    var recurrenceMonthsEl = $('recurrenceMonths');
    if (recurrenceModeEl && recurrenceMonthsEl) {
      var syncRecurrence = function(){
        recurrenceMonthsEl.disabled = recurrenceModeEl.value !== 'Mensal fixa';
      };
      recurrenceModeEl.onchange = syncRecurrence;
      syncRecurrence();
    }
  }

  function openCardForm(card) {
    card = card || { id:'', name:'', firstDigits:'', lastDigits:'', limit:'', closingDay:'20', dueDay:'10', colorName:'Preto', brandName:'Visa' };
    var body = '<div class="form-grid">' + field('Nome do cartão/banco', 'name', 'text', card.name, 'required') + field('Limite', 'limit', 'text', card.limit ? money(card.limit).replace('R$','').trim() : '', 'required') + field('Primeiros dígitos', 'firstDigits', 'text', card.firstDigits || '', 'maxlength="6"') + field('Últimos 4 dígitos', 'lastDigits', 'text', card.lastDigits || '', 'maxlength="4"') + field('Dia fechamento', 'closingDay', 'number', card.closingDay || '20', 'min="1" max="31"') + field('Dia vencimento', 'dueDay', 'number', card.dueDay || '10', 'min="1" max="31"') + selectField('Cor', 'colorName', ['Preto','Roxo','Azul','Verde','Vermelho'], card.colorName || 'Preto') + selectField('Bandeira', 'brandName', ['Visa','Mastercard','Elo','Hipercard','American Express','Outro'], card.brandName || 'Visa') + '</div>';
    showModal(card.id ? 'Editar cartão' : 'Novo cartão', 'Controle limite, fechamento e vencimento.', body, function(fd){
      var obj = { id: card.id || uid(), name: fd.get('name').trim(), firstDigits: fd.get('firstDigits').trim(), lastDigits: fd.get('lastDigits').trim(), limit: parseMoney(fd.get('limit')), closingDay: Number(fd.get('closingDay') || 1), dueDay: Number(fd.get('dueDay') || 1), colorName: fd.get('colorName'), brandName: fd.get('brandName') };
      if (!obj.name || obj.limit <= 0) return toast('Informe nome e limite maior que zero.');
      var idx = state.cards.findIndex(function(c){ return c.id === obj.id; });
      if (idx >= 0) state.cards[idx] = obj; else state.cards.push(obj);
      saveState(); closeModal(); render(); toast('Cartão salvo.');
    });
  }
  function openCardTransactionForm(t, selectedCardId) {
    if (!state.cards.length) { toast('Cadastre um cartão primeiro.'); return openCardForm(); }
    t = t || { id:'', cardId:selectedCardId || state.cards[0].id, title:'', amount:'', category:state.categories.card[0], date:todayBR(), billingMonthOffset:0, installments:1, recurrenceMonths:0, consumeTotalLimit:false, notes:'' };
    var body = '<div class="form-grid">' + field('Descrição da compra', 'title', 'text', t.title, 'required') + field('Valor total', 'amount', 'text', t.amount ? money(t.amount).replace('R$','').trim() : '', 'required') + selectObjectField('Cartão', 'cardId', state.cards.map(function(c){ return { value: c.id, label: c.name }; }), t.cardId) + selectField('Categoria', 'category', state.categories.card, t.category) + field('Data da compra', 'date', 'date', dateInputFromBR(t.date), 'required') + field('Mês cobrança após', 'billingMonthOffset', 'number', t.billingMonthOffset || 0, 'min="0"') + field('Parcelas', 'installments', 'number', t.installments || 1, 'min="1"') + field('Recorrência meses', 'recurrenceMonths', 'number', t.recurrenceMonths || 0, 'min="0"') + '<div class="field"><label>Limite</label><select class="select" name="consumeTotalLimit"><option value="false" ' + (!t.consumeTotalLimit ? 'selected' : '') + '>Consumir parcela no limite</option><option value="true" ' + (t.consumeTotalLimit ? 'selected' : '') + '>Consumir valor total no limite</option></select></div>' + textareaField('Observação', 'notes', t.notes) + '</div>';
    showModal(t.id ? 'Editar compra no cartão' : 'Nova compra no cartão', 'Parcelas e recorrência são calculadas automaticamente na fatura.', body, function(fd){
      var obj = { id: t.id || uid(), cardId: fd.get('cardId'), title: fd.get('title').trim(), amount: parseMoney(fd.get('amount')), category: fd.get('category'), date: dateBRFromInput(fd.get('date')), billingMonthOffset: Number(fd.get('billingMonthOffset') || 0), installments: Math.max(1, Number(fd.get('installments') || 1)), recurrenceMonths: Math.max(0, Number(fd.get('recurrenceMonths') || 0)), consumeTotalLimit: fd.get('consumeTotalLimit') === 'true', notes: fd.get('notes') || '' };
      if (!obj.title || obj.amount <= 0) return toast('Informe descrição e valor maior que zero.');
      var idx = state.cardTransactions.findIndex(function(x){ return x.id === obj.id; });
      if (idx >= 0) state.cardTransactions[idx] = obj; else state.cardTransactions.push(obj);
      saveState(); closeModal(); render(); toast('Compra salva.');
    });
  }
  function openInvoicePayment(cardId) {
    var card = state.cards.find(function(c){ return c.id === cardId; });
    if (!card) return;
    var total = cardInvoiceTotal(cardId, selectedMonth);
    var current = cardInvoicePayment(cardId, selectedMonth) || { paidAmount: total, mode:'Integral', installments:1, interestPercent:0, date:todayBR() };
    var body = '<div class="form-grid">' + field('Valor pago', 'paidAmount', 'text', money(current.paidAmount || total).replace('R$','').trim(), 'required') + selectField('Modo', 'mode', ['Integral','Parcial','Parcelamento'], current.mode || 'Integral') + field('Parcelas', 'installments', 'number', current.installments || 1, 'min="1"') + field('Juros %', 'interestPercent', 'text', current.interestPercent || '0') + field('Data pagamento', 'date', 'date', dateInputFromBR(current.date), 'required') + '</div><p class="card-subtitle" style="margin-top:10px">Fatura calculada: <strong class="yellow">' + money(total) + '</strong></p>';
    showModal('Pagar fatura', card.name + ' · ' + monthTitle(selectedMonth), body, function(fd){
      var p = { id: current.id || uid(), cardId: cardId, month: selectedMonth, mode: fd.get('mode'), paidAmount: parseMoney(fd.get('paidAmount')), installments: Math.max(1, Number(fd.get('installments') || 1)), interestPercent: parseMoney(fd.get('interestPercent')), date: dateBRFromInput(fd.get('date')) };
      state.invoicePayments = state.invoicePayments.filter(function(x){ return !(x.cardId === cardId && x.month === selectedMonth); });
      state.invoicePayments.push(p);
      saveState(); closeModal(); render(); toast('Pagamento de fatura salvo.');
    });
  }

  function openSalaryBaseForm() {
    var t = salaryTotals(selectedMonth), r = t.record;
    var body = '<div class="form-grid">' + field('Salário bruto', 'grossSalary', 'text', r.grossSalary ? money(r.grossSalary).replace('R$','').trim() : '', 'required') + textareaField('Observação', 'notes', r.notes || '') + '</div>';
    showModal('Definir salário', monthTitle(selectedMonth), body, function(fd){
      r.grossSalary = parseMoney(fd.get('grossSalary'));
      r.notes = fd.get('notes') || '';
      upsertSalaryRecord(r); saveState(); closeModal(); render(); toast('Salário salvo.');
    }, 'small');
  }
  function openSalaryItemForm(item) {
    var r = salaryRecordForMonth(selectedMonth);
    item = item || { id:'', name:'', type:'Desconto', valueMode:'Valor', value:'', fixedMonthly:true, startMonth:selectedMonth, endMonth:selectedMonth, notes:'' };
    var body = '<div class="form-grid">' + field('Nome', 'name', 'text', item.name, 'required') + selectField('Tipo', 'type', ['Recebimento','Desconto','Empréstimo CLT'], item.type) + selectField('Modo do valor', 'valueMode', ['Valor','Percentual'], item.valueMode) + field('Valor ou percentual', 'value', 'text', item.value || '', 'required') + '<div class="field" id="salary-recurrence-field"><label>Recorrência</label><select class="select" id="fixedMonthly" name="fixedMonthly"><option value="true" ' + (item.fixedMonthly !== false ? 'selected' : '') + '>Repete nos próximos meses</option><option value="false" ' + (item.fixedMonthly === false ? 'selected' : '') + '>Somente este mês</option></select></div><div class="form-grid form-full" id="salary-loan-period">' + field('Início do contrato', 'startMonth', 'month', item.startMonth || selectedMonth) + field('Fim do contrato', 'endMonth', 'month', item.endMonth || selectedMonth) + '</div>' + textareaField('Observação', 'notes', item.notes || '') + '</div>';
    showModal(item.id ? 'Editar item do salário' : 'Novo item do salário', monthTitle(selectedMonth), body, function(fd){
      var type = fd.get('type');
      var isLoan = type === 'Empréstimo CLT';
      var obj = { id: item.id || uid(), name: fd.get('name').trim(), type: type, valueMode: fd.get('valueMode'), value: parseMoney(fd.get('value')), fixedMonthly: isLoan || fd.get('fixedMonthly') === 'true', startMonth: isLoan ? fd.get('startMonth') : '', endMonth: isLoan ? fd.get('endMonth') : '', notes: fd.get('notes') || '' };
      if (!obj.name || obj.value <= 0) return toast('Informe nome e valor.');
      if (isLoan && (!obj.startMonth || !obj.endMonth)) return toast('Informe o início e o fim do contrato.');
      if (isLoan && obj.endMonth < obj.startMonth) return toast('O fim do contrato não pode ser anterior ao início.');
      if (isLoan) state.salaryRecords.forEach(function(record){ record.items = (record.items || []).filter(function(existing){ return existing.id !== obj.id; }); });
      r.items = r.items || [];
      var idx = r.items.findIndex(function(x){ return x.id === obj.id; });
      if (idx >= 0) r.items[idx] = obj; else r.items.push(obj);
      upsertSalaryRecord(r); saveState(); closeModal(); render(); toast('Item salvo.');
    });
    var typeEl = $('type');
    var periodEl = $('salary-loan-period');
    var recurrenceFieldEl = $('salary-recurrence-field');
    var recurrenceEl = $('fixedMonthly');
    var startEl = $('startMonth');
    var endEl = $('endMonth');
    var syncSalaryItemType = function(){
      var isLoan = typeEl.value === 'Empréstimo CLT';
      periodEl.hidden = !isLoan;
      recurrenceFieldEl.hidden = isLoan;
      recurrenceEl.disabled = isLoan;
      startEl.required = isLoan;
      endEl.required = isLoan;
    };
    typeEl.onchange = syncSalaryItemType;
    syncSalaryItemType();
  }

  function openLoanForm(loan) {
    loan = loan || { id:'', name:'', direction:'Peguei emprestado', principalAmount:'', installmentAmount:'', installments:12, firstDueDate: todayBR(), interestPercent:0, notes:'', payments:[] };
    var body = '<div class="form-grid">' + field('Nome/descrição', 'name', 'text', loan.name, 'required') + selectField('Tipo', 'direction', ['Peguei emprestado','Emprestei para alguém'], loan.direction) + field('Valor principal', 'principalAmount', 'text', loan.principalAmount ? money(loan.principalAmount).replace('R$','').trim() : '', 'required') + field('Valor da parcela', 'installmentAmount', 'text', loan.installmentAmount ? money(loan.installmentAmount).replace('R$','').trim() : '', 'required') + field('Parcelas', 'installments', 'number', loan.installments || 12, 'min="1"') + field('Primeiro vencimento', 'firstDueDate', 'date', dateInputFromBR(loan.firstDueDate), 'required') + field('Juros %', 'interestPercent', 'text', loan.interestPercent || '0') + textareaField('Observação', 'notes', loan.notes || '') + '</div>';
    showModal(loan.id ? 'Editar empréstimo' : 'Novo empréstimo', 'Informe parcelas e vencimento.', body, function(fd){
      var obj = { id: loan.id || uid(), name: fd.get('name').trim(), direction: fd.get('direction'), principalAmount: parseMoney(fd.get('principalAmount')), installmentAmount: parseMoney(fd.get('installmentAmount')), installments: Math.max(1, Number(fd.get('installments') || 1)), firstDueDate: dateBRFromInput(fd.get('firstDueDate')), interestPercent: parseMoney(fd.get('interestPercent')), notes: fd.get('notes') || '', payments: loan.payments || [] };
      if (!obj.name || obj.principalAmount <= 0 || obj.installmentAmount <= 0) return toast('Informe nome, principal e parcela.');
      var idx = state.loans.findIndex(function(x){ return x.id === obj.id; });
      if (idx >= 0) state.loans[idx] = obj; else state.loans.push(obj);
      saveState(); closeModal(); render(); toast('Empréstimo salvo.');
    });
  }
  function openLoanDetails(id) {
    var loan = state.loans.find(function(l){ return l.id === id; });
    if (!loan) return;
    var rows = loanSchedule(loan).map(function(i){
      return '<div class="item"><div class="item-main"><div class="item-title">Parcela ' + i.number + '</div><div class="item-subtitle">Vencimento ' + i.dueDate + (i.paid ? ' · pago em ' + i.paidDate : '') + '</div></div><div class="row"><strong class="yellow">' + money(i.amount) + '</strong><button class="' + (i.paid ? 'secondary-btn' : 'success-btn') + '" data-action="toggle-loan-installment" data-id="' + loan.id + '" data-number="' + i.number + '">' + (i.paid ? 'Estornar' : 'Baixar') + '</button></div></div>';
    }).join('');
    $('modal-root').innerHTML = '<div class="modal-backdrop"><div class="modal"><h2>' + escapeHtml(loan.name) + '</h2><p class="modal-desc">Cronograma de parcelas</p><div class="list">' + rows + '</div><div class="actions"><button type="button" class="secondary-btn" data-action="close-modal">Fechar</button></div></div></div>';
  }

  function openSubscriptionForm(sub) {
    sub = sub || { id:'', name:'', kind:'Aplicativo', amount:'', billingCycle:'Mensal', dueDay:String(new Date().getDate()), startDate:todayBR(), active:true, notes:'' };
    var body = '<div class="form-grid">' + field('Nome', 'name', 'text', sub.name, 'required') + selectField('Tipo', 'kind', ['Aplicativo','Jogo','Streaming','Nuvem','Outro'], sub.kind) + field('Valor', 'amount', 'text', sub.amount ? money(sub.amount).replace('R$','').trim() : '', 'required') + selectField('Ciclo', 'billingCycle', ['Mensal','Trimestral','Anual'], sub.billingCycle) + field('Dia vencimento', 'dueDay', 'number', sub.dueDay || 1, 'min="1" max="31"') + field('Data início', 'startDate', 'date', dateInputFromBR(sub.startDate), 'required') + '<div class="field"><label>Status</label><select class="select" name="active"><option value="true" ' + (sub.active !== false ? 'selected' : '') + '>Ativa</option><option value="false" ' + (sub.active === false ? 'selected' : '') + '>Pausada</option></select></div>' + textareaField('Observação', 'notes', sub.notes || '') + '</div>';
    showModal(sub.id ? 'Editar assinatura' : 'Nova assinatura', 'Controle recorrências mensais, trimestrais e anuais.', body, function(fd){
      var obj = { id: sub.id || uid(), name: fd.get('name').trim(), kind: fd.get('kind'), amount: parseMoney(fd.get('amount')), billingCycle: fd.get('billingCycle'), dueDay: Number(fd.get('dueDay') || 1), startDate: dateBRFromInput(fd.get('startDate')), active: fd.get('active') === 'true', notes: fd.get('notes') || '' };
      if (!obj.name || obj.amount <= 0) return toast('Informe nome e valor.');
      var idx = state.subscriptions.findIndex(function(x){ return x.id === obj.id; });
      if (idx >= 0) state.subscriptions[idx] = obj; else state.subscriptions.push(obj);
      saveState(); closeModal(); render(); toast('Assinatura salva.');
    });
  }

  function openCategoryForm(module) {
    var labels = { income:'Receitas', expense:'Despesas', card:'Cartão', salary:'Salário', loan:'Empréstimos' };
    var body = '<div class="form-grid">' + field('Nome da categoria', 'name', 'text', '', 'required') + '</div>';
    showModal('Nova categoria', labels[module], body, function(fd){
      var name = fd.get('name').trim();
      if (!name) return toast('Informe o nome.');
      if (state.categories[module].map(normalizeText).indexOf(normalizeText(name)) >= 0) return toast('Categoria já cadastrada.');
      state.categories[module].push(name); saveState(); closeModal(); render(); toast('Categoria criada.');
    }, 'small');
  }

  function exportBackup() {
    var data = JSON.stringify(state, null, 2);
    var blob = new Blob([data], { type: 'application/json;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'rb-gestao-financeira-backup-' + selectedMonth + '.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1000);
    toast('Backup exportado.');
  }
  function importBackupFile(file) {
    var reader = new FileReader();
    reader.onload = function(){
      try {
        var parsed = JSON.parse(reader.result);
        state = normalizeState(parsed);
        saveState(); render(); toast('Backup importado com sucesso.');
      } catch (err) { toast('Arquivo JSON inválido.'); }
    };
    reader.readAsText(file, 'utf-8');
  }

  function confirmAction(title, text, onYes) {
    $('modal-root').innerHTML = '<div class="modal-backdrop"><div class="modal small"><h2>' + escapeHtml(title) + '</h2><p class="modal-desc">' + escapeHtml(text) + '</p><div class="actions"><button type="button" class="secondary-btn" data-action="close-modal">Cancelar</button><button type="button" class="danger-btn" id="confirm-yes">Confirmar</button></div></div></div>';
    $('confirm-yes').onclick = function(){ onYes(); closeModal(); };
  }

  function handleClick(ev) {
    var btn = ev.target.closest('button');
    if (!btn) return;
    var screen = btn.getAttribute('data-screen');
    if (screen) return setScreen(screen);
    var action = btn.getAttribute('data-action');
    var id = btn.getAttribute('data-id');
    if (!action) return;
    if (action === 'close-modal') return closeModal();
    if (action === 'new-entry') return openEntryForm();
    if (action === 'edit-entry') return openEntryForm(state.entries.find(function(e){ return e.id === id; }));
    if (action === 'toggle-entry') { var e = state.entries.find(function(x){ return x.id === id; }); if (e) { e.status = e.status === 'Pago' ? 'Previsto' : 'Pago'; saveState(); render(); } return; }
    if (action === 'delete-entry') return confirmAction('Excluir transação', 'Esta ação não pode ser desfeita.', function(){ state.entries = state.entries.filter(function(e){ return e.id !== id; }); saveState(); render(); toast('Transação excluída.'); });
    if (action === 'new-card') return openCardForm();
    if (action === 'edit-card') return openCardForm(state.cards.find(function(c){ return c.id === id; }));
    if (action === 'delete-card') return confirmAction('Excluir cartão', 'As compras deste cartão também serão removidas.', function(){ state.cards = state.cards.filter(function(c){ return c.id !== id; }); state.cardTransactions = state.cardTransactions.filter(function(t){ return t.cardId !== id; }); state.invoicePayments = state.invoicePayments.filter(function(p){ return p.cardId !== id; }); saveState(); render(); toast('Cartão excluído.'); });
    if (action === 'new-card-transaction') return openCardTransactionForm(null, btn.getAttribute('data-card'));
    if (action === 'edit-card-transaction') return openCardTransactionForm(state.cardTransactions.find(function(t){ return t.id === id; }));
    if (action === 'delete-card-transaction') return confirmAction('Excluir compra', 'A compra será removida das faturas.', function(){ state.cardTransactions = state.cardTransactions.filter(function(t){ return t.id !== id; }); saveState(); render(); toast('Compra excluída.'); });
    if (action === 'pay-invoice') return openInvoicePayment(id);
    if (action === 'set-salary') return openSalaryBaseForm();
    if (action === 'new-salary-item') return openSalaryItemForm();
    if (action === 'edit-salary-item') { var r = salaryRecordForMonth(selectedMonth); return openSalaryItemForm((r.items || []).find(function(i){ return i.id === id; })); }
    if (action === 'delete-salary-item') return confirmAction('Excluir item', 'O item será removido. Contratos de empréstimo serão excluídos de toda a vigência.', function(){ var r=salaryRecordForMonth(selectedMonth); var target=(r.items||[]).find(function(i){return i.id===id;}); if(salaryItemIsLoan(target)){ state.salaryRecords.forEach(function(record){record.items=(record.items||[]).filter(function(i){return i.id!==id;});}); } else { r.items=(r.items||[]).filter(function(i){return i.id!==id;}); upsertSalaryRecord(r); } saveState(); render(); toast('Item excluído.'); });
    if (action === 'new-loan') return openLoanForm();
    if (action === 'edit-loan') return openLoanForm(state.loans.find(function(l){ return l.id === id; }));
    if (action === 'delete-loan') return confirmAction('Excluir empréstimo', 'O contrato e suas baixas serão removidos.', function(){ state.loans = state.loans.filter(function(l){ return l.id !== id; }); saveState(); render(); toast('Empréstimo excluído.'); });
    if (action === 'pay-next-loan') { var l=state.loans.find(function(x){return x.id===id;}); var n=l&&nextLoanInstallment(l); if(n){ l.payments=l.payments||[]; l.payments.push({number:n.number, paidDate:todayBR()}); saveState(); render(); toast('Parcela baixada.'); } return; }
    if (action === 'loan-details') return openLoanDetails(id);
    if (action === 'toggle-loan-installment') { var loan=state.loans.find(function(x){return x.id===id;}); var number=Number(btn.getAttribute('data-number')); if(loan){ loan.payments=loan.payments||[]; var exists=loan.payments.some(function(p){return p.number===number;}); loan.payments = exists ? loan.payments.filter(function(p){return p.number!==number;}) : loan.payments.concat([{number:number, paidDate:todayBR()}]); saveState(); openLoanDetails(id); render(); } return; }
    if (action === 'new-subscription') return openSubscriptionForm();
    if (action === 'edit-subscription') return openSubscriptionForm(state.subscriptions.find(function(s){ return s.id === id; }));
    if (action === 'toggle-subscription') { var s=state.subscriptions.find(function(x){return x.id===id;}); if(s){s.active = s.active === false; saveState(); render();} return; }
    if (action === 'delete-subscription') return confirmAction('Excluir assinatura', 'A assinatura será removida.', function(){ state.subscriptions = state.subscriptions.filter(function(s){ return s.id !== id; }); saveState(); render(); toast('Assinatura excluída.'); });
    if (action === 'new-category') return openCategoryForm(btn.getAttribute('data-module'));
    if (action === 'delete-category') return confirmAction('Excluir categoria', 'Os lançamentos existentes continuam com o texto antigo.', function(){ var m=btn.getAttribute('data-module'); var n=btn.getAttribute('data-name'); state.categories[m]=state.categories[m].filter(function(c){return c!==n;}); if(!state.categories[m].length) state.categories[m]=clone(defaultCategories[m]); saveState(); render(); toast('Categoria excluída.'); });
    if (action === 'export-backup') return exportBackup();
    if (action === 'import-backup') return $('import-file').click();
    if (action === 'reset-data') return confirmAction('Zerar todos os dados', 'Todos os dados locais serão apagados. Exporte um backup antes se precisar.', function(){ state = defaultState(); saveState(); render(); toast('Base zerada.'); });
  }

  function init() {
    if (!root.document) return;
    loadState();
    loadUiState();
    document.addEventListener('click', handleClick);
    document.addEventListener('keydown', function(ev){ if (ev.key === 'Escape') closeModal(); });
    $('prev-month').addEventListener('click', function(){ selectedMonth = addMonthsKey(selectedMonth, -1); saveUiState(); render(); });
    $('next-month').addEventListener('click', function(){ selectedMonth = addMonthsKey(selectedMonth, 1); saveUiState(); render(); });
    $('month-label').addEventListener('click', function(){ selectedMonth = addMonthsKey(monthKey(new Date()), 1); saveUiState(); render(); toast('Voltou para o próximo mês.'); });
    $('content').addEventListener('input', function(ev){ if (ev.target && ev.target.id === 'search-box') { searchText = ev.target.value; render(); var box=$('search-box'); if(box){ box.focus(); box.selectionStart = box.selectionEnd = box.value.length; } } });
    $('content').addEventListener('change', function(ev){
      var target = ev.target;
      if (!target || !target.id) return;
      var bindings = {
        'cards-status-filter':['cards','status'], 'cards-sort':['cards','sort'],
        'cards-purchase-card-filter':['cards','purchaseCard'], 'cards-purchase-sort':['cards','purchaseSort'],
        'dashboard-type-filter':['dashboard','type'], 'dashboard-sort':['dashboard','sort'],
        'entries-type-filter':['entries','type'], 'entries-status-filter':['entries','status'], 'entries-sort':['entries','sort'],
        'salary-type-filter':['salary','type'], 'salary-sort':['salary','sort'],
        'loans-direction-filter':['loans','direction'], 'loans-status-filter':['loans','status'], 'loans-sort':['loans','sort'],
        'subscriptions-status-filter':['subscriptions','status'], 'subscriptions-cycle-filter':['subscriptions','cycle'], 'subscriptions-sort':['subscriptions','sort'],
        'categories-sort':['categories','sort']
      };
      var binding = bindings[target.id];
      if (!binding) return;
      viewOptions[binding[0]][binding[1]] = target.value;
      saveUiState();
      render();
    });
    $('import-file').addEventListener('change', function(ev){ if (ev.target.files && ev.target.files[0]) importBackupFile(ev.target.files[0]); ev.target.value = ''; });
    render();
  }

  var Core = {
    defaultState: defaultState,
    normalizeState: normalizeState,
    parseMoney: parseMoney,
    money: money,
    parseDateBR: parseDateBR,
    formatDateBR: formatDateBR,
    monthFromBR: monthFromBR,
    addMonthsKey: addMonthsKey,
    buildRecurringEntries: buildRecurringEntries,
    loanSchedule: loanSchedule,
    nextSubscriptionDue: nextSubscriptionDue,
    subscriptionMonthlyEquivalent: subscriptionMonthlyEquivalent,
    subscriptionAmountForMonth: subscriptionAmountForMonth,
    monthlyMovements: function(customState, key) { var old=state; state=normalizeState(customState); var out=monthlyMovements(key); state=old; return out; },
    cardTransactionIsBilledIn: cardTransactionIsBilledIn,
    cardBilledAmount: cardBilledAmount,
    cardSummary: function(customState, key) {
      var old=state;
      state=normalizeState(customState);
      var transactions=state.cardTransactions.filter(function(t){ return cardTransactionIsBilledIn(t,key); });
      var out=cardSummary(state.cards,key,transactions);
      state=old;
      return out;
    },
    dashboard: function(customState, key) { var old = state; state = normalizeState(customState); var out = dashboard(key); state = old; return out; },
    _setStateForTest: function(customState){ state = normalizeState(customState); }
  };

  root.RBFinanceCore = Core;
  if (typeof module !== 'undefined' && module.exports) module.exports = Core;
  if (root.document) document.addEventListener('DOMContentLoaded', init);
})(typeof window !== 'undefined' ? window : globalThis);
